"""
Load Clean Data & Save Bronze Data
"""

import os

import pandas as pd

from .config import (
    CLEAN_DIR,
    BRONZE_DIR
)


# ==========================================
# Directories
# ==========================================

def ensure_directories():
    """
    Create required directories if they don't exist.
    """

    if not os.path.isdir(CLEAN_DIR):
        os.makedirs(CLEAN_DIR)

    if not os.path.isdir(BRONZE_DIR):
        os.makedirs(BRONZE_DIR)


# ==========================================
# Load Dataset
# ==========================================

def load_dataset(file_name):
    """
    Load dataset from Clean layer.
    """

    path = os.path.join(
        CLEAN_DIR,
        file_name
    )

    if not os.path.exists(path):
        raise FileNotFoundError(
            f"{file_name} not found."
        )

    extension = os.path.splitext(path)[1].lower()

    if extension == ".csv":
        return pd.read_csv(path)

    elif extension == ".xlsx":
        return pd.read_excel(path)

    else:
        raise ValueError(
            f"Unsupported file type: {extension}"
        )


# ==========================================
# Save Dataset
# ==========================================

def save_dataset(df, file_name):
    """
    Save dataset into Bronze layer.
    """

    ensure_directories()

    path = os.path.join(
        BRONZE_DIR,
        file_name
    )

    extension = os.path.splitext(path)[1].lower()

    if extension == ".csv":

        df.to_csv(
            path,
            index=False
        )

    elif extension == ".xlsx":

        df.to_excel(
            path,
            index=False
        )

    else:
        raise ValueError(
            f"Unsupported file type: {extension}"
        )

    print(
        f"Saved Bronze Dataset -> {path}"
    )