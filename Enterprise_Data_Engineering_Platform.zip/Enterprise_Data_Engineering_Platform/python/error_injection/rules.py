"""
Data Quality Error Rules
"""

from dataclasses import dataclass
from typing import Any


# ==========================================
# Base Rule
# ==========================================

@dataclass
class BaseRule:
    """
    Base class for all error injection rules.
    """

    column: str
    rate: float


# ==========================================
# Missing Values
# ==========================================

@dataclass
class MissingRule(BaseRule):
    """
    Inject NULL values.
    """
    pass


# ==========================================
# Duplicate Values
# ==========================================

@dataclass
class DuplicateRule(BaseRule):
    """
    Inject duplicated values.
    """
    pass


# ==========================================
# Invalid Values
# ==========================================

@dataclass
class InvalidRule(BaseRule):
    """
    Inject invalid values.
    """

    values: list[Any]


# ==========================================
# Negative Values
# ==========================================

@dataclass
class NegativeRule(BaseRule):
    """
    Convert numeric values to negative.
    """
    pass


# ==========================================
# Outlier Values
# ==========================================

@dataclass
class OutlierRule(BaseRule):
    """
    Inject extreme values.
    """

    value: Any


# ==========================================
# Case Sensitivity
# ==========================================

@dataclass
class CaseRule(BaseRule):
    """
    Randomize upper/lower/mixed casing.
    """
    pass


# ==========================================
# Future Dates
# ==========================================

@dataclass
class FutureDateRule(BaseRule):
    """
    Inject future dates.
    """

    start_year: int = 2030
    end_year: int = 2035


# ==========================================
# Fixed Value
# ==========================================

@dataclass
class FixedValueRule(BaseRule):
    """
    Replace values with one fixed value.
    """

    value: Any


# ==========================================
# Random Values
# ==========================================

@dataclass
class RandomValueRule(BaseRule):
    """
    Replace values using a random list.
    """

    values: list[Any]


# ==========================================
# Rule Registry
# ==========================================

RULE_TYPES = {
    "missing": MissingRule,
    "duplicate": DuplicateRule,
    "invalid": InvalidRule,
    "negative": NegativeRule,
    "outlier": OutlierRule,
    "case": CaseRule,
    "future_date": FutureDateRule,
    "fixed_value": FixedValueRule,
    "random_value": RandomValueRule,
}