"""
Error Injection Configuration
"""

# ==========================================
# Error Rates
# ==========================================

DEFAULT_ERROR_RATE = 0.01
LOW_ERROR_RATE = 0.005
VERY_LOW_ERROR_RATE = 0.001

# ==========================================
# Directories
# ==========================================

CLEAN_DIR = "data/clean"
BRONZE_DIR = "data/bronze"
LOG_DIR = "logs"

# ==========================================
# Files
# ==========================================

ERROR_LOG_FILE = "error_injection_log.csv"

# ==========================================
# Random Seed
# ==========================================

RANDOM_SEED = 42