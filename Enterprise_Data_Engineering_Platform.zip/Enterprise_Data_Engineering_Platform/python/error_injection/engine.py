"""
Data Quality Error Injection Engine
"""

import os
import random
from datetime import datetime
import pandas as pd

from .rules import (
    MissingRule,
    DuplicateRule,
    InvalidRule,
    NegativeRule,
    OutlierRule,
    CaseRule,
    FutureDateRule,
    FixedValueRule,
    RandomValueRule
)
from .config import ERROR_LOG_FILE


# ==========================================
# 1. Apply Rules (Core Logics)
# ==========================================

def apply_rule(df: pd.DataFrame, rule):
    """
    Apply a single data quality rule to the DataFrame.
    Returns the updated DataFrame and execution statistics.
    """

    df = df.copy()
    n_rows = len(df)

    # Protection: Check if column exists in DataFrame
    if rule.column not in df.columns:
        print(
            f"⚠️ Column '{rule.column}' not found. Skipping {type(rule).__name__}."
        )
        return df, 0, 0

    # Calculate how many rows should be targeted
    n_affected = (
        max(1, int(n_rows * rule.rate))
        if rule.rate > 0
        else 0
    )

    if n_affected == 0 or n_rows == 0:
        return df, 0, 0

    target_indices = random.sample(
        range(n_rows),
        min(n_affected, n_rows)
    )

    targeted_rows = len(target_indices)
    rows_added = 0

    if isinstance(rule, MissingRule):

        df.loc[
            target_indices,
            rule.column
        ] = None

    elif isinstance(rule, DuplicateRule):

        duplicate_rows = df.loc[
            target_indices
        ].copy()

        df = pd.concat(
            [
                df,
                duplicate_rows
            ],
            ignore_index=True
        )

        rows_added = len(duplicate_rows)

    elif isinstance(rule, InvalidRule):

        invalid_values = [
            random.choice(rule.values)
            for _ in range(targeted_rows)
        ]

        df.loc[
            target_indices,
            rule.column
        ] = invalid_values

    elif isinstance(rule, NegativeRule):

        # Protection: Ensure column is numeric before applying NegativeRule
        if not pd.api.types.is_numeric_dtype(df[rule.column]):
            print(
                f"⚠️ Column '{rule.column}' is not numeric. Skipping NegativeRule."
            )
            return df, 0, 0

        df.loc[
            target_indices,
            rule.column
        ] = df.loc[
            target_indices,
            rule.column
        ].apply(
            lambda x: -abs(x)
            if pd.notnull(x)
            else x
        )

    elif isinstance(rule, OutlierRule):

        df.loc[
            target_indices,
            rule.column
        ] = rule.value

    elif isinstance(rule, CaseRule):

        df.loc[
            target_indices,
            rule.column
        ] = df.loc[
            target_indices,
            rule.column
        ].apply(
            lambda x: random.choice([
                str(x).upper(),
                str(x).lower(),
                str(x).title()
            ])
            if pd.notnull(x)
            else x
        )

    elif isinstance(rule, FutureDateRule):

        future_dates = [
            (
                pd.Timestamp.now()
                + pd.Timedelta(
                    days=random.randint(30, 3650)
                )
            ).strftime("%Y-%m-%d")
            for _ in range(targeted_rows)
        ]

        df.loc[
            target_indices,
            rule.column
        ] = future_dates

    elif isinstance(rule, FixedValueRule):

        df.loc[
            target_indices,
            rule.column
        ] = rule.value

    elif isinstance(rule, RandomValueRule):

        df.loc[
            target_indices,
            rule.column
        ] = [
            random.choice(rule.values)
            for _ in range(targeted_rows)
        ]

    return df, targeted_rows, rows_added


# ==========================================
# 2. Execute Rule & Collect Statistics
# ==========================================

def execute_rule(df: pd.DataFrame, rule, batch_id: str = None):
    """
    Execute one rule and return updated DataFrame
    along with detailed execution statistics.
    """

    before = df.copy()
    total_rows = len(df)

    df, targeted_rows, rows_added = apply_rule(
        df,
        rule
    )

    if isinstance(rule, DuplicateRule):

        changed_rows = rows_added

    else:

        common_rows = min(len(before), len(df))

        changed_rows = (
            (before.iloc[:common_rows] != df.iloc[:common_rows])
            & ~(before.iloc[:common_rows].isna() & df.iloc[:common_rows].isna())
        ).any(axis=1).sum()

    actual_error_rate = (
        round(
            changed_rows / total_rows,
            4
        )
        if total_rows > 0
        else 0.0
    )

    log = {
        "batch_id": batch_id,
        "dataset": "",
        "column": rule.column,
        "rule": type(rule).__name__,
        "configured_rate": rule.rate,
        "targeted_rows": int(targeted_rows),
        "affected_rows": int(changed_rows),
        "actual_error_rate": actual_error_rate,
        "total_rows": total_rows,
        "rows_added": int(rows_added),
        "execution_time": datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S"
        )
    }

    return df, log


# ==========================================
# 3. Inject Errors Strategy
# ==========================================

def inject_errors(df: pd.DataFrame, rules: list, dataset_name: str, batch_id: str = None):
    """
    Inject errors across multiple rules for a specific dataset.
    """
    execution_logs = []

    for rule in rules:
        df, log = execute_rule(df, rule, batch_id=batch_id)
        log["dataset"] = dataset_name
        execution_logs.append(log)

    return df, execution_logs


# ==========================================
# 4. Print & Save Execution Logs
# ==========================================

def print_execution_logs(logs: list):
    """
    Print execution logs formatted nicely to the terminal.
    """

    if not logs:
        return

    print("=" * 120)
    print("Executed Rules Summary")
    print("=" * 120)

    print(
        f"{'Dataset':<15}"
        f"{'Column':<20}"
        f"{'Rule':<20}"
        f"{'Targeted':<10}"
        f"{'Affected':<10}"
        f"{'Added':<8}"
        f"{'Actual Rate':<12}"
    )

    print("-" * 120)

    for log in logs:

        print(
            f"{log['dataset']:<15}"
            f"{log['column']:<20}"
            f"{log['rule']:<20}"
            f"{log['targeted_rows']:<10}"
            f"{log['affected_rows']:<10}"
            f"{log['rows_added']:<8}"
            f"{log['actual_error_rate']:<12}"
        )

    print("=" * 120)


def save_execution_logs(logs: list, output_directory: str):
    """
    Save execution logs into a consolidated CSV file inside the target directory.
    """
    if not logs:
        return

    log_df = pd.DataFrame(logs)

    log_file = os.path.join(
        output_directory,
        ERROR_LOG_FILE
    )

    if os.path.exists(log_file):
        old_logs = pd.read_csv(log_file)
        log_df = pd.concat([old_logs, log_df], ignore_index=True)

    log_df.to_csv(log_file, index=False)

    print(f"Execution log saved -> {log_file}")