"""
Data Quality Error Injection Framework Runner
"""

from datetime import datetime

from .loader import (
    load_dataset,
    save_dataset
)

from .engine import (
    inject_errors,
    print_execution_logs,
    save_execution_logs
)

from .config import BRONZE_DIR

from .rules import (
    MissingRule,
    DuplicateRule,
    InvalidRule,
    NegativeRule,
    OutlierRule,
    CaseRule,
    FutureDateRule
)


# ==========================================
# Batch Metadata
# ==========================================

BATCH_ID = datetime.now().strftime("%Y%m%d_%H%M%S")


# ==========================================
# 1. CUSTOMERS
# ==========================================

customer_rules = [

    MissingRule(
        column="email",
        rate=0.01
    ),

    InvalidRule(
        column="gender",
        rate=0.01,
        values=["Other", "N/A", "Unknown"]
    ),

    CaseRule(
        column="city",
        rate=0.01
    ),

    NegativeRule(
        column="annual_income",
        rate=0.005
    )
]


# ==========================================
# 2. ACCOUNTS
# ==========================================

account_rules = [

    MissingRule(
        column="account_type",
        rate=0.005
    ),

    NegativeRule(
        column="balance",
        rate=0.01
    ),

    InvalidRule(
        column="currency",
        rate=0.005,
        values=["XYZ", "123", "INVALID"]
    ),

    FutureDateRule(
        column="opened_date",
        rate=0.002
    )
]


# ==========================================
# 3. CARDS
# ==========================================

card_rules = [

    MissingRule(
        column="card_number",
        rate=0.003
    ),

    InvalidRule(
        column="card_type",
        rate=0.005,
        values=["Unknown", "ABC"]
    ),

    NegativeRule(
        column="credit_limit",
        rate=0.005
    ),

    FutureDateRule(
        column="issued_date",
        rate=0.002
    )
]


# ==========================================
# 4. LOANS
# ==========================================

loan_rules = [

    NegativeRule(
        column="loan_amount",
        rate=0.005
    ),

    NegativeRule(
        column="monthly_installment",
        rate=0.005
    ),

    InvalidRule(
        column="loan_type",
        rate=0.005,
        values=["Test Loan", "Unknown"]
    ),

    FutureDateRule(
        column="start_date",
        rate=0.002
    )
]


# ==========================================
# 5. TRANSACTIONS
# ==========================================

transaction_rules = [

    NegativeRule(
        column="amount",
        rate=0.01
    ),

    InvalidRule(
        column="transaction_type",
        rate=0.005,
        values=["Fake", "Unknown"]
    ),

    FutureDateRule(
        column="transaction_date",
        rate=0.002
    )
]


# ==========================================
# 6. CAMPAIGNS
# ==========================================

campaign_rules = [

    MissingRule(
        column="campaign_name",
        rate=0.01
    ),

    InvalidRule(
        column="channel",
        rate=0.01,
        values=["Spam", "Unknown"]
    ),

    FutureDateRule(
        column="start_date",
        rate=0.002
    )
]


# ==========================================
# 7. BRANCHES
# ==========================================

branch_rules = [

    DuplicateRule(
        column="branch_code",
        rate=0.01
    ),

    MissingRule(
        column="branch_name",
        rate=0.01
    ),

    MissingRule(
        column="city",
        rate=0.01
    ),

    InvalidRule(
        column="status",
        rate=0.01,
        values=["Unknown", "Invalid"]
    ),

    FutureDateRule(
        column="opened_date",
        rate=0.002
    )
]


# ==========================================
# 8. CUSTOMER CAMPAIGNS
# ==========================================

customer_campaign_rules = [

    InvalidRule(
        column="customer_id",
        rate=0.01,
        values=[999999]
    ),

    InvalidRule(
        column="campaign_id",
        rate=0.01,
        values=[999999]
    ),

    InvalidRule(
        column="channel",
        rate=0.01,
        values=["Unknown", "Invalid"]
    ),

    InvalidRule(
        column="response_status",
        rate=0.01,
        values=["Unknown", "Invalid"]
    ),

    InvalidRule(
        column="conversion_flag",
        rate=0.01,
        values=[2]
    ),

    FutureDateRule(
        column="contact_date",
        rate=0.002
    )
]


# ==========================================
# Process Dataset
# ==========================================

def process_dataset(
    file_name: str,
    dataset_name: str,
    rules: list
):
    """
    Load clean dataset,
    inject data quality errors,
    save corrupted dataset to Bronze,
    and log execution.
    """

    try:

        print("=" * 80)
        print(
            f"Processing Dataset: "
            f"{dataset_name} "
            f"(Batch: {BATCH_ID})..."
        )
        print("=" * 80)

        # Load clean dataset
        df = load_dataset(file_name)

        print(
            f"Loaded {len(df):,} clean records"
        )

        # Inject errors
        df, logs = inject_errors(
            df=df,
            rules=rules,
            dataset_name=dataset_name,
            batch_id=BATCH_ID
        )

        # Save corrupted dataset to Bronze
        save_dataset(
            df,
            file_name
        )

        # Print execution summary
        print_execution_logs(logs)

        # Save logs
        save_execution_logs(
            logs,
            BRONZE_DIR
        )

        print(
            f"✅ Successfully processed "
            f"{dataset_name}"
        )

        print(
            f"Bronze Records: {len(df):,}"
        )

        print()

    except Exception as ex:

        print(
            f"❌ Failed to process "
            f"-> {dataset_name}"
        )

        print(
            f"Error Details: {ex}\n"
        )


# ==========================================
# Main Execution
# ==========================================

def main():

    print("\n" + "#" * 80)

    print(
        f"STARTING ERROR INJECTION BATCH: "
        f"{BATCH_ID}"
    )

    print("#" * 80 + "\n")


    # ======================================
    # 1. Customers
    # ======================================

    process_dataset(
        file_name="customers.csv",
        dataset_name="customers",
        rules=customer_rules
    )


    # ======================================
    # 2. Accounts
    # ======================================

    process_dataset(
        file_name="accounts.csv",
        dataset_name="accounts",
        rules=account_rules
    )


    # ======================================
    # 3. Cards
    # ======================================

    process_dataset(
        file_name="cards.csv",
        dataset_name="cards",
        rules=card_rules
    )


    # ======================================
    # 4. Loans
    # ======================================

    process_dataset(
        file_name="loans.csv",
        dataset_name="loans",
        rules=loan_rules
    )


    # ======================================
    # 5. Transactions
    # ======================================

    process_dataset(
        file_name="transactions.csv",
        dataset_name="transactions",
        rules=transaction_rules
    )


    # ======================================
    # 6. Campaigns
    # ======================================

    process_dataset(
        file_name="campaigns.xlsx",
        dataset_name="campaigns",
        rules=campaign_rules
    )


    # ======================================
    # 7. Branches
    # ======================================

    process_dataset(
        file_name="branches.csv",
        dataset_name="branches",
        rules=branch_rules
    )


    # ======================================
    # 8. Customer Campaigns
    # ======================================

    process_dataset(
        file_name="customer_campaigns.csv",
        dataset_name="customer_campaigns",
        rules=customer_campaign_rules
    )


    # ======================================
    # Completed
    # ======================================

    print("=" * 80)

    print(
        "ALL 8 DATASET ERROR INJECTIONS "
        "COMPLETED"
    )

    print(
        f"Batch ID: {BATCH_ID}"
    )

    print("=" * 80 + "\n")


# ==========================================
# Entry Point
# ==========================================

if __name__ == "__main__":
    main()