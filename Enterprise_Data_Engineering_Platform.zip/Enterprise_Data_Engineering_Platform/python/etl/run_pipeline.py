# ============================================================
# ENTERPRISE BANKING ETL PIPELINE
# POLICY-DRIVEN ETL
#
# FULL REFRESH SILVER
#
# Bronze
#   ↓
# Cleaning
#   ↓
# Standardization
#   ↓
# Acceptance Policy
#   ↓
# Validity
#   ↓
# Strict Completeness
#   ↓
# Strict Business Validation
#   ↓
# Transformation
#   ↓
# NOT NULL Validation
#   ↓
# Referential Integrity Validation
#   ↓
# Primary Key Validation
#   ↓
# ├── Accepted → Silver
# └── Rejected → Quarantine
#   ↓
# DQ Recheck
#
# IMPORTANT:
# Silver is rebuilt from Bronze on every ETL batch.
#
# IMPORTANT:
# Invalid / incomplete records are NEVER allowed into Silver.
# They are redirected to Quarantine.
#
# IMPORTANT:
# Silver loading is performed in controlled batches.
# ============================================================

import pyodbc
import pandas as pd
import numpy as np
from datetime import datetime
import traceback


# ============================================================
# CONFIGURATION
# ============================================================

SERVER = r".\SQLEXPRESS"
DATABASE = "EnterpriseBankingDW"
DRIVER = "ODBC Driver 17 for SQL Server"

CONNECTION_STRING = (
    f"DRIVER={{{DRIVER}}};"
    f"SERVER={SERVER};"
    f"DATABASE={DATABASE};"
    f"Trusted_Connection=yes;"
    f"TrustServerCertificate=yes;"
)

BRONZE_SCHEMA = "bronze"
SILVER_SCHEMA = "silver"
DQ_SCHEMA = "dq"

QUARANTINE_TABLE = "dbo.dq_quarantine"

# SQL Server parameter limit
PK_QUERY_CHUNK_SIZE = 1000

# Silver insert batch size
SILVER_INSERT_BATCH_SIZE = 2000

# Quarantine insert batch size
QUARANTINE_BATCH_SIZE = 5000


# ============================================================
# TABLES
# ============================================================

TABLES = [
    "customers",
    "branches",
    "campaigns",
    "accounts",
    "cards",
    "loans",
    "customer_campaigns",
    "transactions"
]


# ============================================================
# PRIMARY KEYS
# ============================================================

PRIMARY_KEYS = {

    "accounts": "account_id",

    "branches": "branch_id",

    "campaigns": "campaign_id",

    "cards": "card_id",

    "customer_campaigns": "customer_campaign_id",

    "customers": "customer_id",

    "loans": "loan_id",

    "transactions": "transaction_id"
}


# ============================================================
# CONNECTION
# ============================================================

def get_connection():

    return pyodbc.connect(
        CONNECTION_STRING
    )


# ============================================================
# LOAD ACCEPTANCE POLICY
# ============================================================

def load_acceptance_policy(conn):

    sql = """
        SELECT
            acceptance_policy_id,
            dimension_name,
            rule_name,
            policy_action,
            cleaning_strategy,
            is_active
        FROM dq.dq_acceptance_policy
        WHERE is_active = 1
        ORDER BY acceptance_policy_id
    """

    policy = pd.read_sql(
        sql,
        conn
    )

    if policy.empty:

        raise RuntimeError(
            "No active Acceptance Policy was found."
        )

    return policy


# ============================================================
# CREATE ETL BATCH
# ============================================================

def create_etl_batch(conn):

    cursor = conn.cursor()

    batch_reference = (
        "ETL_BATCH_"
        + datetime.now().strftime(
            "%Y%m%d%H%M%S%f"
        )
    )

    cursor.execute(
        """
        INSERT INTO dq.dq_batches
        (
            batch_reference,
            pipeline_name,
            started_at,
            status,
            total_datasets,
            total_checks,
            total_failed_checks,
            overall_quality_score
        )
        OUTPUT INSERTED.batch_id
        VALUES
        (
            ?,
            ?,
            SYSDATETIME(),
            ?,
            0,
            0,
            0,
            0
        )
        """,

        batch_reference,
        "Enterprise Banking ETL",
        "Running"
    )

    row = cursor.fetchone()

    if row is None:

        raise RuntimeError(
            "Unable to retrieve ETL batch_id."
        )

    batch_id = int(row[0])

    conn.commit()

    return batch_id


# ============================================================
# RESET SILVER
#
# FULL REFRESH
# ============================================================

def reset_silver(conn):

    cursor = conn.cursor()

    print()
    print("=" * 70)
    print("RESETTING SILVER LAYER")
    print("=" * 70)

    delete_order = [
        "transactions",
        "customer_campaigns",
        "cards",
        "loans",
        "accounts",
        "campaigns",
        "branches",
        "customers"
    ]

    try:

        # ====================================================
        # 1. DISABLE CONSTRAINTS
        # ====================================================

        print(
            "Disabling Silver foreign-key constraints..."
        )

        for table in TABLES:

            cursor.execute(
                f"""
                IF OBJECT_ID(
                    N'[{SILVER_SCHEMA}].[{table}]',
                    N'U'
                ) IS NOT NULL
                BEGIN

                    ALTER TABLE
                        [{SILVER_SCHEMA}].[{table}]
                    NOCHECK CONSTRAINT ALL;

                END
                """
            )

        conn.commit()

        print(
            "✓ Silver constraints disabled"
        )

        # ====================================================
        # 2. CLEAR SILVER TABLES
        # ====================================================

        print()
        print(
            "Clearing Silver tables..."
        )

        for table in delete_order:

            total_deleted = 0

            while True:

                cursor.execute(
                    f"""
                    DELETE TOP (5000)
                    FROM
                        [{SILVER_SCHEMA}].[{table}]
                    """
                )

                deleted = cursor.rowcount

                if deleted is None:
                    deleted = 0

                if deleted == 0:
                    break

                total_deleted += deleted

                conn.commit()

                if total_deleted % 50000 == 0:

                    print(
                        f"   Deleted batch: "
                        f"{deleted:,} | "
                        f"Total: "
                        f"{total_deleted:,}"
                    )

            print(
                f"✓ Cleared "
                f"{SILVER_SCHEMA}.{table} "
                f"({total_deleted:,} rows)"
            )

        # ====================================================
        # 3. RE-ENABLE CONSTRAINTS
        # ====================================================

        print()
        print(
            "Re-enabling Silver constraints..."
        )

        for table in TABLES:

            cursor.execute(
                f"""
                ALTER TABLE
                    [{SILVER_SCHEMA}].[{table}]
                WITH CHECK
                CHECK CONSTRAINT ALL;
                """
            )

        conn.commit()

        print(
            "✓ Silver constraints re-enabled"
        )

        print()
        print(
            "✓ Silver layer reset completed successfully"
        )

    except Exception:

        conn.rollback()

        print()
        print(
            "✗ Failed to reset Silver layer"
        )

        raise

    print("=" * 70)


# ============================================================
# LOAD BRONZE
# ============================================================

def load_bronze(
    conn,
    table
):

    sql = f"""
        SELECT *
        FROM [{BRONZE_SCHEMA}].[{table}]
    """

    return pd.read_sql(
        sql,
        conn
    )


# ============================================================
# GET SILVER COLUMNS
# ============================================================

def get_silver_columns(
    conn,
    table
):

    sql = """
        SELECT
            COLUMN_NAME,
            IS_NULLABLE,
            ORDINAL_POSITION
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = ?
          AND TABLE_NAME = ?
        ORDER BY ORDINAL_POSITION
    """

    result = pd.read_sql(
        sql,
        conn,
        params=[
            SILVER_SCHEMA,
            table
        ]
    )

    if result.empty:

        raise RuntimeError(
            f"Silver table not found: "
            f"{SILVER_SCHEMA}.{table}"
        )

    return result


# ============================================================
# GET SILVER NOT NULL COLUMNS
# ============================================================

def get_silver_required_columns(
    conn,
    table
):

    metadata = get_silver_columns(
        conn,
        table
    )

    required = metadata[
        metadata["IS_NULLABLE"] == "NO"
    ]["COLUMN_NAME"].tolist()

    return required


# ============================================================
# CLEANING
# ============================================================

def apply_cleaning(df):

    df = df.copy()

    string_columns = df.select_dtypes(
        include=[
            "object",
            "string"
        ]
    ).columns

    for col in string_columns:

        df[col] = df[col].apply(
            lambda x:
                x.strip()
                if isinstance(x, str)
                else x
        )

        df[col] = df[col].replace(
            [
                "",
                "NULL",
                "null",
                "N/A",
                "n/a",
                "NA",
                "na",
                "None",
                "none"
            ],
            np.nan
        )

    return df


# ============================================================
# STANDARDIZATION
# ============================================================

def apply_standardization(
    df,
    policy
):

    df = df.copy()

    # --------------------------------------------------------
    # TRIM
    # --------------------------------------------------------

    trim_required = policy[
        policy["cleaning_strategy"]
        .fillna("")
        .astype(str)
        .str.upper()
        .str.contains("TRIM")
    ]

    if not trim_required.empty:

        for col in df.select_dtypes(
            include=[
                "object",
                "string"
            ]
        ).columns:

            df[col] = df[col].apply(
                lambda x:
                    x.strip()
                    if isinstance(x, str)
                    else x
            )

    # --------------------------------------------------------
    # GENDER
    # --------------------------------------------------------

    if "gender" in df.columns:

        gender_map = {

            "m": "Male",
            "M": "Male",
            "male": "Male",
            "MALE": "Male",

            "f": "Female",
            "F": "Female",
            "female": "Female",
            "FEMALE": "Female",

            "o": "Other",
            "O": "Other",
            "other": "Other",
            "OTHER": "Other"
        }

        df["gender"] = (
            df["gender"]
            .astype("string")
            .str.strip()
            .map(
                lambda x:
                    gender_map.get(
                        x,
                        x
                    )
                    if pd.notna(x)
                    else x
            )
        )

    # --------------------------------------------------------
    # ACCOUNT TYPE
    # --------------------------------------------------------

    if "account_type" in df.columns:

        mapping = {

            "savings": "Savings",
            "SAVINGS": "Savings",

            "checking": "Checking",
            "CHECKING": "Checking",

            "current": "Current",
            "CURRENT": "Current",

            "business": "Business",
            "BUSINESS": "Business",

            "salary": "Salary",
            "SALARY": "Salary"
        }

        df["account_type"] = (
            df["account_type"]
            .astype("string")
            .str.strip()
            .replace(mapping)
        )

    # --------------------------------------------------------
    # LOAN TYPE
    # --------------------------------------------------------

    if "loan_type" in df.columns:

        mapping = {

            "personal": "Personal",
            "PERSONAL": "Personal",

            "auto": "Auto",
            "AUTO": "Auto",

            "mortgage": "Mortgage",
            "MORTGAGE": "Mortgage",

            "business": "Business",
            "BUSINESS": "Business",

            "home": "Home",
            "HOME": "Home",

            "education": "Education",
            "EDUCATION": "Education"
        }

        df["loan_type"] = (
            df["loan_type"]
            .astype("string")
            .str.strip()
            .replace(mapping)
        )

    # --------------------------------------------------------
    # CARD TYPE
    # --------------------------------------------------------

    if "card_type" in df.columns:

        mapping = {

            "debit": "Debit",
            "DEBIT": "Debit",

            "credit": "Credit",
            "CREDIT": "Credit",

            "prepaid": "Prepaid",
            "PREPAID": "Prepaid"
        }

        df["card_type"] = (
            df["card_type"]
            .astype("string")
            .str.strip()
            .replace(mapping)
        )

    # --------------------------------------------------------
    # CARD NETWORK
    # --------------------------------------------------------

    if "network" in df.columns:

        mapping = {

            "visa": "Visa",
            "VISA": "Visa",

            "mastercard": "Mastercard",
            "MASTERCARD": "Mastercard",

            "american express":
                "American Express",

            "AMERICAN EXPRESS":
                "American Express"
        }

        df["network"] = (
            df["network"]
            .astype("string")
            .str.strip()
            .replace(mapping)
        )

    # --------------------------------------------------------
    # TRANSACTION TYPE
    # --------------------------------------------------------

    if "transaction_type" in df.columns:

        mapping = {

            "deposit": "Deposit",
            "DEPOSIT": "Deposit",

            "withdrawal": "Withdrawal",
            "WITHDRAWAL": "Withdrawal",

            "transfer": "Transfer",
            "TRANSFER": "Transfer",

            "payment": "Payment",
            "PAYMENT": "Payment",

            "purchase": "Purchase",
            "PURCHASE": "Purchase"
        }

        df["transaction_type"] = (
            df["transaction_type"]
            .astype("string")
            .str.strip()
            .replace(mapping)
        )

    # --------------------------------------------------------
    # CURRENCY
    # --------------------------------------------------------

    if "currency" in df.columns:

        df["currency"] = (
            df["currency"]
            .astype("string")
            .str.strip()
            .str.upper()
        )

    # --------------------------------------------------------
    # STATUS
    # --------------------------------------------------------

    if "status" in df.columns:

        df["status"] = (
            df["status"]
            .astype("string")
            .str.strip()
        )

    # --------------------------------------------------------
    # CHANNEL
    # --------------------------------------------------------

    if "channel" in df.columns:

        df["channel"] = (
            df["channel"]
            .astype("string")
            .str.strip()
        )

    # --------------------------------------------------------
    # DATE CONVERSION
    # --------------------------------------------------------

    for col in df.columns:

        if (
            "date" in col.lower()
            or col.lower()
            in [
                "opened_date",
                "issued_date",
                "start_date",
                "end_date",
                "contact_date"
            ]
        ):

            try:

                df[col] = pd.to_datetime(
                    df[col],
                    errors="coerce"
                )

            except Exception:

                pass

    return df


# ============================================================
# RULE ACTION
# ============================================================

def rule_action(
    policy,
    rule_name
):

    rows = policy[
        policy["rule_name"]
        .astype(str)
        .str.lower()
        ==
        rule_name.lower()
    ]

    if rows.empty:

        return None

    return str(
        rows.iloc[0]["policy_action"]
    ).upper().strip()


# ============================================================
# ACCEPTANCE POLICY ENGINE
# ============================================================

def apply_acceptance_policy(
    df,
    policy,
    table
):

    df = df.copy()

    rejected = pd.Series(
        False,
        index=df.index
    )

    rejection_reason = pd.Series(
        "",
        index=df.index,
        dtype="object"
    )

    active_policy = policy[
        policy["is_active"] == True
    ].copy()

    for _, rule in active_policy.iterrows():

        rule_name = str(
            rule["rule_name"]
        ).strip()

        dimension = str(
            rule["dimension_name"]
        ).strip()

        action = str(
            rule["policy_action"]
        ).upper().strip()

        # ----------------------------------------------------
        # OUTLIER
        # ----------------------------------------------------

        if dimension.lower() == "outlier":

            continue

        # ----------------------------------------------------
        # CLEAN AND RECHECK
        #
        # IMPORTANT:
        # Cleaning is handled first.
        # Strict validation happens later.
        # ----------------------------------------------------

        if action == "CLEAN_AND_RECHECK":

            continue

        # ----------------------------------------------------
        # COMPLETENESS
        # ----------------------------------------------------

        if dimension.lower() == "completeness":

            if action != "REJECT":

                continue

            if "missing" in rule_name.lower():

                invalid = df.isna().any(
                    axis=1
                )

                new_rejections = (
                    invalid &
                    ~rejected
                )

                rejection_reason.loc[
                    new_rejections
                ] = rule_name

                rejected |= invalid

            continue

        # ----------------------------------------------------
        # UNIQUENESS
        # ----------------------------------------------------

        if dimension.lower() == "uniqueness":

            if action != "REJECT":

                continue

            pk = PRIMARY_KEYS.get(
                table
            )

            if pk and pk in df.columns:

                invalid = (
                    df[pk].duplicated(
                        keep="first"
                    )
                    |
                    df[pk].isna()
                )

                new_rejections = (
                    invalid &
                    ~rejected
                )

                rejection_reason.loc[
                    new_rejections
                ] = rule_name

                rejected |= invalid

            continue

        # ----------------------------------------------------
        # REFERENTIAL INTEGRITY
        # ----------------------------------------------------

        if (
            dimension.lower()
            == "referential integrity"
        ):

            continue

        # ----------------------------------------------------
        # VALIDITY EXPRESSION
        # ----------------------------------------------------

        if (
            dimension.lower()
            == "validity expression"
        ):

            if action != "REJECT":

                continue

            invalid = evaluate_expression_rule(
                df,
                rule_name,
                table
            )

            new_rejections = (
                invalid &
                ~rejected
            )

            rejection_reason.loc[
                new_rejections
            ] = rule_name

            rejected |= invalid

            continue

        # ----------------------------------------------------
        # VALIDITY
        # ----------------------------------------------------

        if dimension.lower() == "validity":

            continue

    accepted = df[
        ~rejected
    ].copy()

    rejected_df = df[
        rejected
    ].copy()

    reasons = rejection_reason[
        rejected
    ].copy()

    return (
        accepted,
        rejected_df,
        reasons
    )


# ============================================================
# VALIDITY EXPRESSION ENGINE
# ============================================================

def evaluate_expression_rule(
    df,
    rule_name,
    table
):

    rule = rule_name.lower()

    invalid = pd.Series(
        False,
        index=df.index
    )

    # --------------------------------------------------------
    # NUMERIC RULES
    # --------------------------------------------------------

    numeric_rule_map = {

        "annual income cannot be negative":
            "annual_income",

        "account balance cannot be negative":
            "balance",

        "credit limit cannot be negative":
            "credit_limit",

        "loan principal cannot be negative":
            "principal_amount",

        "monthly installment cannot be negative":
            "monthly_installment",

        "transaction amount cannot be negative":
            "amount"
    }

    for rule_text, column in numeric_rule_map.items():

        if rule_text in rule:

            if column in df.columns:

                numeric = pd.to_numeric(
                    df[column],
                    errors="coerce"
                )

                invalid |= (
                    numeric < 0
                )

            return invalid

    # --------------------------------------------------------
    # CONVERSION FLAG
    # --------------------------------------------------------

    if (
        "conversion flag" in rule
        and "conversion_flag" in df.columns
    ):

        invalid |= ~df[
            "conversion_flag"
        ].isin([0, 1])

        return invalid

    # --------------------------------------------------------
    # FUTURE DATES
    # --------------------------------------------------------

    future_date_rules = {

        "opened date":
            "opened_date",

        "issued date":
            "issued_date",

        "loan start date":
            "start_date",

        "transaction date":
            "transaction_date",

        "campaign start date":
            "start_date",

        "contact date":
            "contact_date"
    }

    for rule_text, column in future_date_rules.items():

        if (
            rule_text in rule
            and "future" in rule
        ):

            if column in df.columns:

                dates = pd.to_datetime(
                    df[column],
                    errors="coerce"
                )

                invalid |= (
                    dates >
                    pd.Timestamp.now()
                )

            return invalid

    return invalid


# ============================================================
# VALIDITY VALUE CHECK
#
# General validity validation.
# ============================================================

def validate_known_values(
    df,
    policy
):

    df = df.copy()

    rejected = pd.Series(
        False,
        index=df.index
    )

    reasons = pd.Series(
        "",
        index=df.index,
        dtype="object"
    )

    allowed_values = {

        "gender": {
            "Male",
            "Female",
            "Other"
        },

        "risk_segment": {
            "Low",
            "Medium",
            "High"
        },

        "account_type": {
            "Savings",
            "Checking",
            "Current",
            "Business",
            "Salary"
        },

        "currency": {
            "USD",
            "EUR",
            "GBP",
            "AED",
            "SAR"
        },

        "card_type": {
            "Debit",
            "Credit",
            "Prepaid"
        },

        "network": {
            "Visa",
            "Mastercard",
            "American Express"
        },

        "card_status": {
            "Active",
            "Blocked",
            "Expired",
            "Cancelled"
        },

        "loan_type": {
            "Personal",
            "Auto",
            "Mortgage",
            "Business",
            "Home",
            "Education"
        },

        "loan_status": {
            "Active",
            "Closed",
            "Defaulted",
            "Pending"
        },

        "transaction_type": {
            "Deposit",
            "Withdrawal",
            "Transfer",
            "Payment",
            "Purchase"
        },

        "response_status": {
            "Responded",
            "Pending",
            "Rejected",
            "No Response",
            "Accepted"
        },

        "channel": {
            "Email",
            "SMS",
            "Phone Call",
            "Mobile App",
            "Social Media",
            "ATM",
            "Internet Banking",
            "Branch",
            "POS"
        },

        "status": {
            "Active",
            "Closed",
            "Completed",
            "Failed",
            "Blocked",
            "Expired",
            "Cancelled",
            "Planned"
        }
    }

    for column, allowed in allowed_values.items():

        if column not in df.columns:

            continue

        # ----------------------------------------------------
        # FIXED:
        #
        # Previously this searched for:
        # "valid channel"
        #
        # which does NOT match:
        # "Valid Campaign Channel"
        #
        # Now we search by column name and Valid keyword.
        # ----------------------------------------------------

        column_text = column.replace(
            "_",
            " "
        ).lower()

        matching = policy[
            policy["rule_name"]
            .astype(str)
            .str.lower()
            .str.contains(
                "valid",
                regex=False
            )
            &
            policy["rule_name"]
            .astype(str)
            .str.lower()
            .str.contains(
                column_text,
                regex=False
            )
        ]

        if matching.empty:

            continue

        # ----------------------------------------------------
        # If the rule exists and is REJECT, enforce it.
        # ----------------------------------------------------

        reject_actions = matching[
            matching["policy_action"]
            .astype(str)
            .str.upper()
            .str.strip()
            == "REJECT"
        ]

        clean_actions = matching[
            matching["policy_action"]
            .astype(str)
            .str.upper()
            .str.strip()
            == "CLEAN_AND_RECHECK"
        ]

        if (
            reject_actions.empty
            and
            clean_actions.empty
        ):

            continue

        invalid = (
            df[column].notna()
            &
            ~df[column].isin(
                allowed
            )
        )

        new_rejections = (
            invalid &
            ~rejected
        )

        if new_rejections.any():

            reasons.loc[
                new_rejections
            ] = matching.iloc[0][
                "rule_name"
            ]

        rejected |= invalid

    return (
        df[~rejected].copy(),
        df[rejected].copy(),
        reasons[rejected].copy()
    )


# ============================================================
# STRICT COMPLETENESS VALIDATION
#
# IMPORTANT:
# Business-critical completeness rules are enforced here.
#
# This specifically prevents:
#
# customers.email = NULL
#
# from entering Silver.
# ============================================================

def validate_completeness(
    df,
    table
):

    df = df.copy()

    rejected = pd.Series(
        False,
        index=df.index
    )

    reasons = pd.Series(
        "",
        index=df.index,
        dtype="object"
    )

    # ========================================================
    # CUSTOMERS EMAIL
    # ========================================================

    if table == "customers":

        if "email" in df.columns:

            missing_email = (
                df["email"].isna()
                |
                (
                    df["email"]
                    .astype("string")
                    .str.strip()
                    == ""
                )
            )

            rejected |= missing_email

            reasons.loc[
                missing_email
            ] = (
                "Missing Value Check - "
                "customers.email"
            )

    # ========================================================
    # RETURN
    # ========================================================

    accepted = df[
        ~rejected
    ].copy()

    rejected_df = df[
        rejected
    ].copy()

    rejected_reasons = reasons[
        rejected
    ].copy()

    return (
        accepted,
        rejected_df,
        rejected_reasons
    )


# ============================================================
# STRICT SILVER BUSINESS / VALUE VALIDATION
#
# IMPORTANT:
# Nothing invalid is allowed into Silver.
#
# These rules specifically address the failures observed:
#
# customers.email       → missing values
# branches.status       → Unknown
# campaigns.channel     → Spam
# customer_campaigns.channel
#                         → Unknown / Invalid
# ============================================================

def validate_silver_business_rules(
    df,
    table
):

    df = df.copy()

    rejected = pd.Series(
        False,
        index=df.index
    )

    reasons = pd.Series(
        "",
        index=df.index,
        dtype="object"
    )

    def reject(
        mask,
        reason
    ):

        nonlocal rejected
        nonlocal reasons

        new_rejections = (
            mask &
            ~rejected
        )

        reasons.loc[
            new_rejections
        ] = reason

        rejected |= mask

    # ========================================================
    # CUSTOMERS
    # ========================================================

    if table == "customers":

        if "email" in df.columns:

            missing_email = (
                df["email"].isna()
                |
                (
                    df["email"]
                    .astype("string")
                    .str.strip()
                    == ""
                )
            )

            reject(
                missing_email,
                "Missing Value Check - customers.email"
            )

    # ========================================================
    # BRANCHES
    # ========================================================

    elif table == "branches":

        if "status" in df.columns:

            allowed_status = {
                "Active",
                "Closed",
                "Completed",
                "Failed",
                "Blocked",
                "Expired",
                "Cancelled",
                "Planned"
            }

            invalid_status = (
                df["status"].notna()
                &
                ~df["status"].isin(
                    allowed_status
                )
            )

            reject(
                invalid_status,
                "Valid Branch Status"
            )

    # ========================================================
    # CAMPAIGNS
    # ========================================================

    elif table == "campaigns":

        if "channel" in df.columns:

            allowed_channels = {
                "Email",
                "SMS",
                "Phone Call",
                "Mobile App",
                "Social Media",
                "ATM",
                "Internet Banking",
                "Branch",
                "POS"
            }

            invalid_channel = (
                df["channel"].notna()
                &
                ~df["channel"].isin(
                    allowed_channels
                )
            )

            reject(
                invalid_channel,
                "Valid Campaign Channel"
            )

    # ========================================================
    # CUSTOMER CAMPAIGNS
    # ========================================================

    elif table == "customer_campaigns":

        if "channel" in df.columns:

            allowed_channels = {
                "Email",
                "SMS",
                "Phone Call",
                "Mobile App",
                "Social Media",
                "ATM",
                "Internet Banking",
                "Branch",
                "POS"
            }

            invalid_channel = (
                df["channel"].notna()
                &
                ~df["channel"].isin(
                    allowed_channels
                )
            )

            reject(
                invalid_channel,
                "Valid Campaign Channel"
            )

    # ========================================================
    # RETURN
    # ========================================================

    accepted = df[
        ~rejected
    ].copy()

    rejected_df = df[
        rejected
    ].copy()

    rejected_reasons = reasons[
        rejected
    ].copy()

    return (
        accepted,
        rejected_df,
        rejected_reasons
    )


# ============================================================
# TRANSFORM BRONZE → SILVER
# ============================================================

def transform_to_silver(
    conn,
    df,
    table
):

    metadata = get_silver_columns(
        conn,
        table
    )

    silver_columns = (
        metadata[
            "COLUMN_NAME"
        ].tolist()
    )

    available = [
        col
        for col in silver_columns
        if col in df.columns
    ]

    result = df[
        available
    ].copy()

    # --------------------------------------------------------
    # CREATED AT
    # --------------------------------------------------------

    if "created_at" in silver_columns:

        if "created_at" not in result.columns:

            result["created_at"] = datetime.now()

    # --------------------------------------------------------
    # UPDATED AT
    # --------------------------------------------------------

    if "updated_at" in silver_columns:

        if "updated_at" not in result.columns:

            result["updated_at"] = None

    # --------------------------------------------------------
    # SILVER LOADED AT
    # --------------------------------------------------------

    if "silver_loaded_at" in silver_columns:

        result["silver_loaded_at"] = (
            datetime.now()
        )

    final_columns = [
        col
        for col in silver_columns
        if col in result.columns
    ]

    result = result[
        final_columns
    ]

    return result


# ============================================================
# NOT NULL VALIDATION
# ============================================================

def validate_not_null(
    conn,
    df,
    table
):

    if df.empty:

        return (
            df,
            df,
            pd.Series(
                dtype="object"
            )
        )

    required_columns = (
        get_silver_required_columns(
            conn,
            table
        )
    )

    technical_columns = {
        "silver_loaded_at",
        "created_at",
        "updated_at"
    }

    required_columns = [
        col
        for col in required_columns
        if col not in technical_columns
    ]

    missing_columns = [
        col
        for col in required_columns
        if col not in df.columns
    ]

    if missing_columns:

        raise ValueError(
            f"{table}: Required Silver columns "
            f"missing: {missing_columns}"
        )

    invalid_mask = (
        df[
            required_columns
        ]
        .isna()
        .any(axis=1)
    )

    accepted = df[
        ~invalid_mask
    ].copy()

    rejected = df[
        invalid_mask
    ].copy()

    reasons = pd.Series(
        "",
        index=rejected.index,
        dtype="object"
    )

    for idx in rejected.index:

        null_columns = [
            col
            for col in required_columns
            if pd.isna(
                rejected.loc[
                    idx,
                    col
                ]
            )
        ]

        reasons.loc[idx] = (
            "NOT NULL violation: "
            + ", ".join(
                null_columns
            )
        )

    return (
        accepted,
        rejected,
        reasons
    )


# ============================================================
# PRIMARY KEY VALIDATION
# ============================================================

def validate_primary_key(
    conn,
    df,
    table
):

    if df.empty:

        return (
            df,
            df,
            pd.Series(
                dtype="object"
            )
        )

    pk = PRIMARY_KEYS[
        table
    ]

    if pk not in df.columns:

        raise ValueError(
            f"{table}: Primary key "
            f"{pk} not found."
        )

    null_pk = df[
        pk
    ].isna()

    duplicate_inside = (
        df[
            pk
        ].duplicated(
            keep="first"
        )
    )

    invalid_mask = (
        null_pk |
        duplicate_inside
    )

    accepted = df[
        ~invalid_mask
    ].copy()

    rejected = df[
        invalid_mask
    ].copy()

    reasons = pd.Series(
        "",
        index=rejected.index,
        dtype="object"
    )

    for idx in rejected.index:

        value = rejected.loc[
            idx,
            pk
        ]

        if pd.isna(value):

            reasons.loc[idx] = (
                f"NULL primary key: {pk}"
            )

        else:

            reasons.loc[idx] = (
                f"Duplicate primary key "
                f"inside ETL batch: "
                f"{pk}={value}"
            )

    return (
        accepted,
        rejected,
        reasons
    )


# ============================================================
# REFERENTIAL INTEGRITY VALIDATION
# ============================================================

def validate_referential_integrity(
    conn,
    df,
    table,
    policy
):

    if df.empty:

        return (
            df,
            df,
            pd.Series(
                dtype="object"
            )
        )

    rejected = pd.Series(
        False,
        index=df.index
    )

    reasons = pd.Series(
        "",
        index=df.index,
        dtype="object"
    )

    fk_map = {

        "accounts": [
            (
                "customer_id",
                "customers",
                "customer_id",
                "Valid Customer Reference"
            ),
            (
                "branch_id",
                "branches",
                "branch_id",
                "Valid Branch Reference"
            )
        ],

        "cards": [
            (
                "account_id",
                "accounts",
                "account_id",
                "Valid Account Reference"
            )
        ],

        "customer_campaigns": [
            (
                "customer_id",
                "customers",
                "customer_id",
                "Valid Customer Reference"
            ),
            (
                "campaign_id",
                "campaigns",
                "campaign_id",
                "Valid Campaign Reference"
            )
        ],

        "loans": [
            (
                "customer_id",
                "customers",
                "customer_id",
                "Valid Customer Reference"
            ),
            (
                "branch_id",
                "branches",
                "branch_id",
                "Valid Branch Reference"
            )
        ],

        "transactions": [
            (
                "account_id",
                "accounts",
                "account_id",
                "Valid Account Reference"
            )
        ]
    }

    for (
        fk_column,
        ref_table,
        ref_column,
        rule_name
    ) in fk_map.get(
        table,
        []
    ):

        action = rule_action(
            policy,
            rule_name
        )

        if action != "REJECT":

            continue

        if fk_column not in df.columns:

            continue

        values = (
            df[
                fk_column
            ]
            .dropna()
            .unique()
            .tolist()
        )

        if not values:

            continue

        existing = set()

        for start in range(
            0,
            len(values),
            PK_QUERY_CHUNK_SIZE
        ):

            chunk = values[
                start:
                start + PK_QUERY_CHUNK_SIZE
            ]

            placeholders = ",".join(
                ["?"] * len(chunk)
            )

            sql = f"""
                SELECT [{ref_column}]
                FROM [{SILVER_SCHEMA}].[{ref_table}]
                WHERE [{ref_column}] IN (
                    {placeholders}
                )
            """

            cursor = conn.cursor()

            cursor.execute(
                sql,
                *chunk
            )

            rows = cursor.fetchall()

            existing.update(
                row[0]
                for row in rows
            )

        invalid = (
            df[
                fk_column
            ].notna()
            &
            ~df[
                fk_column
            ].isin(
                existing
            )
        )

        new_rejections = (
            invalid
            &
            ~rejected
        )

        reasons.loc[
            new_rejections
        ] = (
            rule_name
            + " - Parent record does not exist "
            "in Silver"
        )

        rejected |= invalid

    accepted = df[
        ~rejected
    ].copy()

    rejected_df = df[
        rejected
    ].copy()

    rejected_reasons = reasons[
        rejected
    ].copy()

    return (
        accepted,
        rejected_df,
        rejected_reasons
    )


# ============================================================
# QUARANTINE
# ============================================================

def quarantine_records(
    conn,
    df,
    table,
    batch_id,
    reasons
):

    if df.empty:

        return 0

    pk = PRIMARY_KEYS[
        table
    ]

    rows = []

    total_inserted = 0

    cursor = conn.cursor()

    for idx, row in df.iterrows():

        if (
            pk in row.index
            and
            not pd.isna(
                row[pk]
            )
        ):

            record_key = str(
                row[pk]
            )

        else:

            record_key = str(
                idx
            )

        reason = reasons.get(
            idx,
            "ETL validation failed"
        )

        rows.append(
            (
                batch_id,
                table,
                record_key,
                str(reason)
            )
        )

        if len(rows) >= QUARANTINE_BATCH_SIZE:

            cursor.fast_executemany = True

            cursor.executemany(
                """
                INSERT INTO dbo.dq_quarantine
                (
                    batch_id,
                    table_name,
                    record_key,
                    rejection_reason,
                    rejected_at
                )
                VALUES
                (
                    ?,
                    ?,
                    ?,
                    ?,
                    SYSDATETIME()
                )
                """,
                rows
            )

            conn.commit()

            total_inserted += len(rows)

            rows = []

    if rows:

        cursor.fast_executemany = True

        cursor.executemany(
            """
            INSERT INTO dbo.dq_quarantine
            (
                batch_id,
                table_name,
                record_key,
                rejection_reason,
                rejected_at
            )
            VALUES
            (
                ?,
                ?,
                ?,
                ?,
                SYSDATETIME()
            )
            """,
            rows
        )

        conn.commit()

        total_inserted += len(rows)

    return total_inserted


# ============================================================
# VALUE CONVERSION FOR SQL SERVER
# ============================================================

def prepare_sql_value(value):

    if pd.isna(value):

        return None

    if isinstance(
        value,
        pd.Timestamp
    ):

        return value.to_pydatetime()

    if isinstance(
        value,
        np.generic
    ):

        return value.item()

    return value


# ============================================================
# LOAD SILVER
# ============================================================

def load_silver(
    conn,
    df,
    table
):

    if df.empty:

        return 0

    df = df.copy()

    silver_metadata = (
        get_silver_columns(
            conn,
            table
        )
    )

    silver_columns = (
        silver_metadata[
            "COLUMN_NAME"
        ].tolist()
    )

    # --------------------------------------------------------
    # SILVER LOADED AT
    # --------------------------------------------------------

    if "silver_loaded_at" in silver_columns:

        df[
            "silver_loaded_at"
        ] = datetime.now()

    # --------------------------------------------------------
    # KEEP ONLY SILVER COLUMNS
    # --------------------------------------------------------

    columns = [
        col
        for col in silver_columns
        if col in df.columns
    ]

    df = df[
        columns
    ].copy()

    if df.empty:

        return 0

    column_sql = ", ".join(
        f"[{col}]"
        for col in columns
    )

    placeholders = ", ".join(
        "?"
        for _ in columns
    )

    sql = f"""
        INSERT INTO
        [{SILVER_SCHEMA}].[{table}]
        (
            {column_sql}
        )
        VALUES
        (
            {placeholders}
        )
    """

    total_rows = len(df)

    total_loaded = 0

    cursor = conn.cursor()

    # --------------------------------------------------------
    # CONTROLLED BATCH INSERT
    # --------------------------------------------------------

    for start in range(
        0,
        total_rows,
        SILVER_INSERT_BATCH_SIZE
    ):

        end = min(
            start + SILVER_INSERT_BATCH_SIZE,
            total_rows
        )

        chunk_df = df.iloc[
            start:end
        ]

        rows = []

        for row in chunk_df.itertuples(
            index=False
        ):

            values = [
                prepare_sql_value(value)
                for value in row
            ]

            rows.append(
                values
            )

        if not rows:

            continue

        try:

            cursor.fast_executemany = True

            cursor.executemany(
                sql,
                rows
            )

            conn.commit()

            total_loaded += len(rows)

            if (
                total_loaded % 10000 == 0
                or
                total_loaded == total_rows
            ):

                print(
                    f"   Inserted: "
                    f"{total_loaded:,} / "
                    f"{total_rows:,}"
                )

        except Exception:

            conn.rollback()

            print()
            print(
                f"✗ Failed while loading "
                f"silver.{table}"
            )

            print(
                f"   Batch range: "
                f"{start:,} - {end:,}"
            )

            raise

        del rows
        del chunk_df

    return total_loaded


# ============================================================
# DQ RECHECK
# ============================================================

def dq_recheck(
    conn,
    batch_id
):

    procedures = [

        "dq.sp_Final_Check_Completeness",

        "dq.sp_Final_Check_Validity",

        "dq.sp_Final_Check_ValidityExpression",

        "dq.sp_Final_Check_Consistency",

        "dq.sp_Final_Check_ReferentialIntegrity",

        "dq.sp_Final_Check_Uniqueness"
    ]

    cursor = conn.cursor()

    print()
    print("=" * 70)
    print("FINAL SILVER DQ RECHECK")
    print("=" * 70)

    for procedure in procedures:

        print(
            f"Running {procedure}..."
        )

        try:

            cursor.execute(
                f"""
                EXEC {procedure}
                @Batch_ID = ?
                """,
                batch_id
            )

            while cursor.nextset():
                pass

            print(
                f"✓ {procedure} completed"
            )

        except Exception as e:

            print(
                f"⚠ Warning: {procedure} "
                f"failed: {e}"
            )

    conn.commit()

    print()
    print(
        "✓ Final Silver DQ Recheck completed successfully."
    )


# ============================================================
# FINALIZE BATCH
# ============================================================

def complete_batch(
    conn,
    batch_id,
    loaded,
    quarantined
):

    cursor = conn.cursor()

    print()
    print(
        "Calculating final DQ batch statistics..."
    )

    # ========================================================
    # FIND DQ RESULT TABLE
    # ========================================================

    cursor.execute("""
        SELECT
            t.name
        FROM sys.tables t
        INNER JOIN sys.schemas s
            ON t.schema_id = s.schema_id

        WHERE s.name = 'dq'

        AND EXISTS (
            SELECT 1
            FROM sys.columns c
            WHERE c.object_id = t.object_id
              AND c.name = 'batch_id'
        )

        AND EXISTS (
            SELECT 1
            FROM sys.columns c
            WHERE c.object_id = t.object_id
              AND c.name = 'status'
        )

        ORDER BY
            CASE
                WHEN t.name = 'data_quality_results'
                    THEN 1
                WHEN t.name = 'dq_results'
                    THEN 2
                WHEN t.name = 'dq_check_results'
                    THEN 3
                ELSE 10
            END,
            t.name
    """)

    result_tables = cursor.fetchall()

    if not result_tables:

        raise RuntimeError(
            "No DQ result table was found in schema [dq]. "
            "The DQ stored procedures must write their results "
            "to a table containing batch_id and status."
        )

    dq_result_table = result_tables[0][0]

    print(
        f"✓ DQ Result Table: "
        f"dq.{dq_result_table}"
    )

    # ========================================================
    # TOTAL CHECKS
    # ========================================================

    sql = f"""
        SELECT
            COUNT(*) AS total_checks,

            SUM(
                CASE
                    WHEN UPPER(
                        LTRIM(
                            RTRIM(status)
                        )
                    ) = 'FAILED'
                    THEN 1
                    ELSE 0
                END
            ) AS total_failed_checks

        FROM [dq].[{dq_result_table}]

        WHERE batch_id = ?
    """

    cursor.execute(
        sql,
        batch_id
    )

    row = cursor.fetchone()

    if row is None:

        total_checks = 0
        total_failed_checks = 0

    else:

        total_checks = int(
            row[0] or 0
        )

        total_failed_checks = int(
            row[1] or 0
        )

    # ========================================================
    # QUALITY SCORE
    # ========================================================

    if total_checks > 0:

        overall_quality_score = (
            (
                total_checks
                - total_failed_checks
            )
            / total_checks
        ) * 100.0

    else:

        overall_quality_score = 0.0

    # ========================================================
    # STATUS
    # ========================================================

    if (
        quarantined > 0
        or total_failed_checks > 0
    ):

        status = (
            "Completed With Failures"
        )

    else:

        status = "Completed"

    # ========================================================
    # UPDATE BATCH
    # ========================================================

    cursor.execute(
        """
        UPDATE dq.dq_batches

        SET
            completed_at =
                SYSDATETIME(),

            status = ?,

            total_datasets = ?,

            total_checks = ?,

            total_failed_checks = ?,

            overall_quality_score = ?

        WHERE batch_id = ?
        """,

        status,
        len(TABLES),
        total_checks,
        total_failed_checks,
        overall_quality_score,
        batch_id
    )

    conn.commit()

    # ========================================================
    # SUMMARY
    # ========================================================

    print()
    print("=" * 70)
    print("FINAL BATCH DQ SUMMARY")
    print("=" * 70)

    print(
        f"Batch ID           : {batch_id}"
    )

    print(
        f"Total Checks       : {total_checks}"
    )

    print(
        f"Failed Checks      : {total_failed_checks}"
    )

    print(
        f"Quality Score      : "
        f"{overall_quality_score:.2f}%"
    )

    print(
        f"Records Loaded     : {loaded:,}"
    )

    print(
        f"Records Quarantined: {quarantined:,}"
    )

    print(
        f"Batch Status       : {status}"
    )

    print("=" * 70)


# ============================================================
# MAIN PIPELINE
# ============================================================

def run_pipeline():

    start_time = datetime.now()

    print()
    print("=" * 70)
    print("ENTERPRISE BANKING ETL PIPELINE")
    print("POLICY-DRIVEN ETL")
    print("FULL REFRESH SILVER")
    print("=" * 70)

    conn = None

    total_loaded = 0

    total_quarantined = 0

    try:

        conn = get_connection()

        # ====================================================
        # 1/8 CREATE BATCH
        # ====================================================

        print()
        print("[1/8] CREATE ETL BATCH")

        batch_id = create_etl_batch(
            conn
        )

        print(
            f"✓ ETL Batch created: "
            f"{batch_id}"
        )

        # ====================================================
        # 2/8 ACCEPTANCE POLICY
        # ====================================================

        print()
        print(
            "[2/8] LOAD ACCEPTANCE POLICY"
        )

        policy = load_acceptance_policy(
            conn
        )

        print(
            f"✓ Active policies loaded: "
            f"{len(policy)}"
        )

        print()
        print(
            "Acceptance Policy Summary:"
        )

        summary = (
            policy[
                "policy_action"
            ]
            .astype(str)
            .str.upper()
            .value_counts()
        )

        for action, count in summary.items():

            print(
                f"  {action}: {count}"
            )

        # ====================================================
        # 3/8 RESET SILVER
        # ====================================================

        print()
        print(
            "[3/8] RESET SILVER LAYER"
        )

        reset_silver(
            conn
        )

        # ====================================================
        # 4/8 PROCESS TABLES
        # ====================================================

        print()
        print(
            "[4/8] PROCESS BRONZE TABLES"
        )

        for table in TABLES:

            print()
            print("=" * 70)

            print(
                f"PROCESSING: {table}"
            )

            print("=" * 70)

            # ------------------------------------------------
            # LOAD BRONZE
            # ------------------------------------------------

            print(
                "Loading Bronze..."
            )

            bronze_df = load_bronze(
                conn,
                table
            )

            print(
                f"Bronze records: "
                f"{len(bronze_df):,}"
            )

            # ------------------------------------------------
            # CLEANING
            # ------------------------------------------------

            print(
                "Cleaning..."
            )

            df = apply_cleaning(
                bronze_df
            )

            print(
                "✓ Cleaning completed"
            )

            # ------------------------------------------------
            # STANDARDIZATION
            # ------------------------------------------------

            print(
                "Standardization..."
            )

            df = apply_standardization(
                df,
                policy
            )

            print(
                "✓ Standardization completed"
            )

            # ------------------------------------------------
            # ACCEPTANCE POLICY
            # ------------------------------------------------

            print(
                "Applying Acceptance Policy..."
            )

            (
                accepted_df,
                rejected_df,
                reasons
            ) = apply_acceptance_policy(
                df,
                policy,
                table
            )

            print(
                f"Policy Accepted: "
                f"{len(accepted_df):,}"
            )

            print(
                f"Policy Rejected: "
                f"{len(rejected_df):,}"
            )

            # ------------------------------------------------
            # QUARANTINE POLICY REJECTED
            # ------------------------------------------------

            if not rejected_df.empty:

                q_count = (
                    quarantine_records(
                        conn,
                        rejected_df,
                        table,
                        batch_id,
                        reasons
                    )
                )

                total_quarantined += q_count

                print(
                    f"✓ Policy Quarantined: "
                    f"{q_count:,}"
                )

            # ------------------------------------------------
            # VALIDITY
            # ------------------------------------------------

            print(
                "Validity Recheck..."
            )

            (
                accepted_df,
                validity_rejected,
                validity_reasons
            ) = validate_known_values(
                accepted_df,
                policy
            )

            if not validity_rejected.empty:

                q_count = (
                    quarantine_records(
                        conn,
                        validity_rejected,
                        table,
                        batch_id,
                        validity_reasons
                    )
                )

                total_quarantined += q_count

            print(
                f"Validity rejected: "
                f"{len(validity_rejected):,}"
            )

            # ------------------------------------------------
            # STRICT COMPLETENESS
            #
            # NEW
            #
            # Specifically catches customers.email NULL.
            # ------------------------------------------------

            print(
                "Strict Completeness Validation..."
            )

            (
                accepted_df,
                completeness_rejected,
                completeness_reasons
            ) = validate_completeness(
                accepted_df,
                table
            )

            if not completeness_rejected.empty:

                q_count = (
                    quarantine_records(
                        conn,
                        completeness_rejected,
                        table,
                        batch_id,
                        completeness_reasons
                    )
                )

                total_quarantined += q_count

            print(
                f"Completeness rejected: "
                f"{len(completeness_rejected):,}"
            )

            # ------------------------------------------------
            # STRICT BUSINESS VALIDATION
            #
            # NEW
            #
            # Catches:
            #
            # branches.status = Unknown
            # campaigns.channel = Spam
            # customer_campaigns.channel =
            #     Unknown / Invalid
            # ------------------------------------------------

            print(
                "Strict Business Value Validation..."
            )

            (
                accepted_df,
                business_rejected,
                business_reasons
            ) = validate_silver_business_rules(
                accepted_df,
                table
            )

            if not business_rejected.empty:

                q_count = (
                    quarantine_records(
                        conn,
                        business_rejected,
                        table,
                        batch_id,
                        business_reasons
                    )
                )

                total_quarantined += q_count

            print(
                f"Business validation rejected: "
                f"{len(business_rejected):,}"
            )

            # ------------------------------------------------
            # TRANSFORMATION
            # ------------------------------------------------

            print(
                "Bronze → Silver Transformation..."
            )

            silver_df = transform_to_silver(
                conn,
                accepted_df,
                table
            )

            print(
                f"Transformed records: "
                f"{len(silver_df):,}"
            )

            # ------------------------------------------------
            # NOT NULL
            # ------------------------------------------------

            print(
                "Checking Silver NOT NULL..."
            )

            (
                silver_df,
                null_rejected,
                null_reasons
            ) = validate_not_null(
                conn,
                silver_df,
                table
            )

            if not null_rejected.empty:

                q_count = (
                    quarantine_records(
                        conn,
                        null_rejected,
                        table,
                        batch_id,
                        null_reasons
                    )
                )

                total_quarantined += q_count

            print(
                f"NOT NULL rejected: "
                f"{len(null_rejected):,}"
            )

            # ------------------------------------------------
            # REFERENTIAL INTEGRITY
            # ------------------------------------------------

            print(
                "Checking Referential Integrity..."
            )

            (
                silver_df,
                ri_rejected,
                ri_reasons
            ) = validate_referential_integrity(
                conn,
                silver_df,
                table,
                policy
            )

            if not ri_rejected.empty:

                q_count = (
                    quarantine_records(
                        conn,
                        ri_rejected,
                        table,
                        batch_id,
                        ri_reasons
                    )
                )

                total_quarantined += q_count

            print(
                f"RI rejected: "
                f"{len(ri_rejected):,}"
            )

            # ------------------------------------------------
            # PRIMARY KEY
            # ------------------------------------------------

            print(
                "Checking Primary Key..."
            )

            (
                silver_df,
                pk_rejected,
                pk_reasons
            ) = validate_primary_key(
                conn,
                silver_df,
                table
            )

            if not pk_rejected.empty:

                q_count = (
                    quarantine_records(
                        conn,
                        pk_rejected,
                        table,
                        batch_id,
                        pk_reasons
                    )
                )

                total_quarantined += q_count

            print(
                f"PK rejected: "
                f"{len(pk_rejected):,}"
            )

            # ------------------------------------------------
            # LOAD SILVER
            # ------------------------------------------------

            print(
                "Loading accepted records to Silver..."
            )

            loaded = load_silver(
                conn,
                silver_df,
                table
            )

            total_loaded += loaded

            print(
                f"✓ Silver loaded: "
                f"{loaded:,}"
            )

            print(
                f"✓ Total quarantined: "
                f"{total_quarantined:,}"
            )

            # ------------------------------------------------
            # FREE MEMORY
            # ------------------------------------------------

            del bronze_df
            del df
            del accepted_df
            del rejected_df
            del silver_df

        # ====================================================
        # 7/8 DQ RECHECK
        # ====================================================

        print()
        print(
            "[7/8] DQ RECHECK"
        )

        dq_recheck(
            conn,
            batch_id
        )

        print(
            "✓ DQ Recheck completed"
        )

        # ====================================================
        # 8/8 FINALIZE
        # ====================================================

        print()
        print(
            "[8/8] FINALIZE ETL BATCH"
        )

        complete_batch(
            conn,
            batch_id,
            total_loaded,
            total_quarantined
        )

        end_time = datetime.now()

        print()
        print("=" * 70)
        print(
            "ETL PIPELINE COMPLETED"
        )
        print("=" * 70)

        print(
            f"Batch ID           : "
            f"{batch_id}"
        )

        print(
            f"Tables processed   : "
            f"{len(TABLES)}"
        )

        print(
            f"Records loaded     : "
            f"{total_loaded:,}"
        )

        print(
            f"Records quarantined: "
            f"{total_quarantined:,}"
        )

        print(
            f"Start time         : "
            f"{start_time}"
        )

        print(
            f"End time           : "
            f"{end_time}"
        )

        print(
            f"Duration           : "
            f"{end_time - start_time}"
        )

        print("=" * 70)

    except Exception as e:

        print()
        print("=" * 70)
        print(
            "✗ PIPELINE FAILED"
        )
        print("=" * 70)

        print(
            f"ERROR: {e}"
        )

        traceback.print_exc()

        raise

    finally:

        if conn is not None:

            conn.close()


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":

    run_pipeline()