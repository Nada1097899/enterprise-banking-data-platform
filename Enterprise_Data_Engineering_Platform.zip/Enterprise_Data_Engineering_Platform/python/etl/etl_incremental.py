# ============================================================
# ENTERPRISE BANKING - INCREMENTAL ETL
# ============================================================
#
# INCREMENTAL PIPELINE
#
# 1. Read Watermark
# 2. Extract Delta
# 3. Cleaning
# 4. Standardization
# 5. DQ Validation
# 6. Quarantine
# 7. Silver MERGE
# 8. Incremental DQ Recheck
# 9. Update Watermark
#
# IMPORTANT:
# This file REUSES the existing ETL/DQ logic from run_pipeline.py
# instead of duplicating it.
#
# run_pipeline.py remains the source of:
#
#   - Cleaning
#   - Standardization
#   - Acceptance Policy
#   - Validity
#   - Completeness
#   - Business Validation
#   - Transformation
#   - NOT NULL
#   - Referential Integrity
#   - Primary Key
#   - Quarantine
#   - DQ Recheck
#
# This file adds:
#
#   - Incremental Watermark
#   - Delta Extraction
#   - Silver MERGE
#   - Watermark Update
#
# ============================================================


import pyodbc
import pandas as pd
import numpy as np

from datetime import datetime


# ============================================================
# CONFIGURATION
# ============================================================

SERVER = r".\SQLEXPRESS"
DATABASE = "EnterpriseBankingDW"
DRIVER = "ODBC Driver 17 for SQL Server"

CONNECTION_STRING = (
    f"DRIVER={{{DRIVER}}};"
    f"SERVER={SERVER};"
    f"DATABASE={DATABASE};"
    f"Trusted_Connection=yes;"
    f"TrustServerCertificate=yes;"
)


# ============================================================
# TABLES
# ============================================================

TABLES = [
    "customers",
    "branches",
    "campaigns",
    "accounts",
    "cards",
    "loans",
    "customer_campaigns",
    "transactions"
]


# ============================================================
# PRIMARY KEYS
# ============================================================

PRIMARY_KEYS = {

    "customers":
        "customer_id",

    "branches":
        "branch_id",

    "campaigns":
        "campaign_id",

    "accounts":
        "account_id",

    "cards":
        "card_id",

    "loans":
        "loan_id",

    "customer_campaigns":
        "customer_campaign_id",

    "transactions":
        "transaction_id"
}


# ============================================================
# CONNECTION
# ============================================================

def get_connection():

    conn = pyodbc.connect(
        CONNECTION_STRING
    )

    print(
        "✓ Database connection successful"
    )

    return conn


# ============================================================
# IMPORT EXISTING ETL FUNCTIONS
# ============================================================

def load_existing_etl_functions():

    from run_pipeline import (

        load_acceptance_policy,

        create_etl_batch,

        apply_cleaning,

        apply_standardization,

        apply_acceptance_policy,

        validate_known_values,

        validate_completeness,

        validate_silver_business_rules,

        transform_to_silver,

        validate_not_null,

        validate_referential_integrity,

        validate_primary_key,

        quarantine_records,

        dq_recheck,

        get_silver_columns

    )

    return {

        "load_acceptance_policy":
            load_acceptance_policy,

        "create_etl_batch":
            create_etl_batch,

        "apply_cleaning":
            apply_cleaning,

        "apply_standardization":
            apply_standardization,

        "apply_acceptance_policy":
            apply_acceptance_policy,

        "validate_known_values":
            validate_known_values,

        "validate_completeness":
            validate_completeness,

        "validate_silver_business_rules":
            validate_silver_business_rules,

        "transform_to_silver":
            transform_to_silver,

        "validate_not_null":
            validate_not_null,

        "validate_referential_integrity":
            validate_referential_integrity,

        "validate_primary_key":
            validate_primary_key,

        "quarantine_records":
            quarantine_records,

        "dq_recheck":
            dq_recheck,

        "get_silver_columns":
            get_silver_columns
    }


# ============================================================
# READ WATERMARK
# ============================================================

def get_watermark(
    conn,
    table_name
):

    sql = """
        SELECT
            table_name,
            watermark_column,
            last_processed_at,
            last_processed_key,
            last_batch_id
        FROM dq.dq_watermarks
        WHERE table_name = ?
    """

    df = pd.read_sql(
        sql,
        conn,
        params=[table_name]
    )

    if df.empty:

        raise ValueError(
            f"No watermark found for table: "
            f"{table_name}"
        )

    row = df.iloc[0]

    return {

        "table_name":
            row["table_name"],

        "watermark_column":
            row["watermark_column"],

        "last_processed_at":
            row["last_processed_at"],

        "last_processed_key":
            row["last_processed_key"],

        "last_batch_id":
            row["last_batch_id"]
    }


# ============================================================
# EXTRACT DELTA
# ============================================================

def extract_delta(
    conn,
    table_name,
    watermark
):

    watermark_column = (
        watermark["watermark_column"]
    )

    last_processed_at = (
        watermark["last_processed_at"]
    )

    last_processed_key = watermark["last_processed_key"]

    if pd.notna(last_processed_key):
       last_processed_key = int(last_processed_key)
    else:
       last_processed_key = None

    primary_key = PRIMARY_KEYS[
        table_name
    ]

    print(
        f"\nExtracting delta: "
        f"{table_name}"
    )

    # ========================================================
    # FIRST RUN / NULL WATERMARK
    # ========================================================

    if pd.isna(last_processed_at):

        query = f"""
            SELECT *
            FROM bronze.[{table_name}]
            ORDER BY
                [{watermark_column}],
                [{primary_key}]
        """

        df = pd.read_sql(
            query,
            conn
        )

        print(
            f"Delta records    : "
            f"{len(df):,}"
        )

        return df

    # ========================================================
    # NORMAL INCREMENTAL EXTRACTION
    # ========================================================

    if (
        last_processed_key is None
        or
        pd.isna(last_processed_key)
    ):

        query = f"""
            SELECT *
            FROM bronze.[{table_name}]
            WHERE
                [{watermark_column}] > ?

            ORDER BY
                [{watermark_column}],
                [{primary_key}]
        """

        df = pd.read_sql(
            query,
            conn,
            params=[
                last_processed_at
            ]
        )

    else:

        query = f"""
            SELECT *
            FROM bronze.[{table_name}]
            WHERE
                [{watermark_column}] > ?

                OR

                (
                    [{watermark_column}] = ?
                    AND
                    [{primary_key}] > ?
                )

            ORDER BY
                [{watermark_column}],
                [{primary_key}]
        """

        df = pd.read_sql(
            query,
            conn,
            params=[
                last_processed_at,
                last_processed_at,
                last_processed_key
            ]
        )

    print(
        f"Delta records    : "
        f"{len(df):,}"
    )

    return df


# ============================================================
# GET NEW WATERMARK
# ============================================================

def get_new_watermark(
    df,
    watermark_column,
    primary_key
):

    if df.empty:

        return None, None

    temp = df.copy()

    temp[watermark_column] = pd.to_datetime(
        temp[watermark_column],
        errors="coerce"
    )

    temp = temp[
        temp[watermark_column].notna()
    ].copy()

    if temp.empty:

        return None, None

    max_timestamp = temp[
        watermark_column
    ].max()

    candidates = temp[
        temp[watermark_column]
        == max_timestamp
    ].copy()

    candidates = candidates.sort_values(
        by=primary_key
    )

    max_key = candidates.iloc[-1][
        primary_key
    ]

    return (
        max_timestamp,
        max_key
    )


# ============================================================
# UPDATE WATERMARK
# ============================================================

def update_watermark(
    conn,
    table_name,
    new_processed_at,
    new_processed_key,
    batch_id
):

    if (
        new_processed_at is None
        or
        new_processed_key is None
    ):

        print(
            f"✓ No watermark update required "
            f"for {table_name}"
        )

        return

    sql = """
        UPDATE dq.dq_watermarks

        SET
            last_processed_at = ?,
            last_processed_key = ?,
            last_batch_id = ?,
            updated_at = SYSDATETIME()

        WHERE
            table_name = ?
    """

    cursor = conn.cursor()

    cursor.execute(
        sql,
        new_processed_at,
        str(new_processed_key),
        batch_id,
        table_name
    )

    if cursor.rowcount == 0:

        raise RuntimeError(
            f"Watermark update failed for "
            f"{table_name}"
        )

    conn.commit()

    print(
        f"✓ Watermark updated for "
        f"{table_name}"
    )

    print(
        f"  Last Processed At : "
        f"{new_processed_at}"
    )

    print(
        f"  Last Processed Key: "
        f"{new_processed_key}"
    )

    print(
        f"  Last Batch ID     : "
        f"{batch_id}"
    )


# ============================================================
# PREPARE SQL VALUE
# ============================================================

def prepare_sql_value(
    value
):

    if pd.isna(value):

        return None

    if isinstance(
        value,
        pd.Timestamp
    ):

        return value.to_pydatetime()

    if isinstance(
        value,
        np.generic
    ):

        return value.item()

    return value


# ============================================================
# SILVER MERGE
# ============================================================

def merge_to_silver(
    conn,
    df,
    table,
    get_silver_columns
):

    if df.empty:

        print(
            "✓ No accepted records to MERGE"
        )

        return 0

    primary_key = PRIMARY_KEYS[
        table
    ]

    if primary_key not in df.columns:

        raise ValueError(
            f"{table}: Primary key "
            f"{primary_key} not found."
        )

    metadata = get_silver_columns(
        conn,
        table
    )

    silver_columns = (
        metadata[
            "COLUMN_NAME"
        ].tolist()
    )

    columns = [
        col
        for col in silver_columns
        if col in df.columns
    ]

    if primary_key not in columns:

        raise ValueError(
            f"{table}: PK {primary_key} "
            f"is not a Silver column."
        )

    working_df = df[
        columns
    ].copy()

    if "silver_loaded_at" in columns:

        working_df[
            "silver_loaded_at"
        ] = datetime.now()

    source_columns_sql = ", ".join(
        f"[{col}]"
        for col in columns
    )

    source_select_sql = ", ".join(
        f"? AS [{col}]"
        for col in columns
    )

    update_columns = [
        col
        for col in columns
        if col != primary_key
        and col != "created_at"
    ]

    update_sql = ", ".join(
        f"target.[{col}] = source.[{col}]"
        for col in update_columns
    )

    insert_columns_sql = ", ".join(
        f"[{col}]"
        for col in columns
    )

    insert_values_sql = ", ".join(
        f"source.[{col}]"
        for col in columns
    )

    merge_sql = f"""
        MERGE silver.[{table}]
        AS target

        USING
        (
            SELECT
                {source_select_sql}
        )
        AS source

        ON
            target.[{primary_key}]
            =
            source.[{primary_key}]

        WHEN MATCHED THEN

            UPDATE SET
                {update_sql}

        WHEN NOT MATCHED BY TARGET THEN

            INSERT
            (
                {insert_columns_sql}
            )

            VALUES
            (
                {insert_values_sql}
            );
    """

    cursor = conn.cursor()

    total_processed = 0

    for _, row in working_df.iterrows():

        values = [
            prepare_sql_value(
                row[col]
            )
            for col in columns
        ]

        cursor.execute(
            merge_sql,
            *values
        )

        total_processed += 1

    conn.commit()

    print(
        f"✓ Silver MERGE completed: "
        f"{total_processed:,} records"
    )

    return total_processed


# ============================================================
# PROCESS ONE TABLE
# ============================================================

def process_table(
    conn,
    table,
    watermark,
    policy,
    batch_id,
    etl
):

    print()
    print("=" * 70)

    print(
        f"PROCESSING INCREMENTAL DELTA: "
        f"{table}"
    )

    print("=" * 70)

    # ========================================================
    # 1. EXTRACT DELTA
    # ========================================================

    delta_df = extract_delta(
        conn,
        table,
        watermark
    )

    extracted_count = len(
        delta_df
    )

    if delta_df.empty:

        print(
            "✓ No delta records to process"
        )

        return {
            "table":
                table,
            "extracted":
                0,
            "loaded":
                0,
            "quarantined":
                0,
            "watermark_at":
                None,
            "watermark_key":
                None
        }

    # ========================================================
    # CALCULATE WATERMARK FROM EXTRACTED DELTA
    # ========================================================

    watermark_at, watermark_key = (
        get_new_watermark(
            delta_df,
            watermark[
                "watermark_column"
            ],
            PRIMARY_KEYS[
                table
            ]
        )
    )

    # ========================================================
    # 2. CLEANING
    # ========================================================

    print()
    print(
        "Cleaning delta..."
    )

    print(
        f"Records before cleaning : "
        f"{len(delta_df):,}"
    )

    cleaned_df = etl[
        "apply_cleaning"
    ](
        delta_df
    )

    print(
        f"Records after cleaning  : "
        f"{len(cleaned_df):,}"
    )

    print(
        "✓ Incremental cleaning completed"
    )

    # ========================================================
    # 3. STANDARDIZATION
    # ========================================================

    print()
    print(
        "Standardizing delta..."
    )

    standardized_df = etl[
        "apply_standardization"
    ](
        cleaned_df,
        policy
    )

    print(
        f"Records after standardization : "
        f"{len(standardized_df):,}"
    )

    print(
        "✓ Incremental standardization completed"
    )

    # ========================================================
    # 4. ACCEPTANCE POLICY
    # ========================================================

    print()
    print(
        "Applying Acceptance Policy..."
    )

    (
        accepted_df,
        rejected_df,
        rejection_reasons
    ) = etl[
        "apply_acceptance_policy"
    ](
        standardized_df,
        policy,
        table
    )

    print(
        f"Policy Accepted : "
        f"{len(accepted_df):,}"
    )

    print(
        f"Policy Rejected : "
        f"{len(rejected_df):,}"
    )

    total_quarantined = 0

    # ========================================================
    # 5. POLICY QUARANTINE
    # ========================================================

    if not rejected_df.empty:

        count = etl[
            "quarantine_records"
        ](
            conn,
            rejected_df,
            table,
            batch_id,
            rejection_reasons
        )

        total_quarantined += count

        print(
            f"✓ Policy quarantined: "
            f"{count:,}"
        )

    # ========================================================
    # 6. VALIDITY
    # ========================================================

    print()
    print(
        "Validity Validation..."
    )

    (
        accepted_df,
        validity_rejected,
        validity_reasons
    ) = etl[
        "validate_known_values"
    ](
        accepted_df,
        policy
    )

    if not validity_rejected.empty:

        count = etl[
            "quarantine_records"
        ](
            conn,
            validity_rejected,
            table,
            batch_id,
            validity_reasons
        )

        total_quarantined += count

    print(
        f"Validity rejected: "
        f"{len(validity_rejected):,}"
    )

    # ========================================================
    # 7. COMPLETENESS
    # ========================================================

    print()
    print(
        "Strict Completeness Validation..."
    )

    (
        accepted_df,
        completeness_rejected,
        completeness_reasons
    ) = etl[
        "validate_completeness"
    ](
        accepted_df,
        table
    )

    if not completeness_rejected.empty:

        count = etl[
            "quarantine_records"
        ](
            conn,
            completeness_rejected,
            table,
            batch_id,
            completeness_reasons
        )

        total_quarantined += count

    print(
        f"Completeness rejected: "
        f"{len(completeness_rejected):,}"
    )

    # ========================================================
    # 8. BUSINESS VALIDATION
    # ========================================================

    print()
    print(
        "Strict Business Validation..."
    )

    (
        accepted_df,
        business_rejected,
        business_reasons
    ) = etl[
        "validate_silver_business_rules"
    ](
        accepted_df,
        table
    )

    if not business_rejected.empty:

        count = etl[
            "quarantine_records"
        ](
            conn,
            business_rejected,
            table,
            batch_id,
            business_reasons
        )

        total_quarantined += count

    print(
        f"Business rejected: "
        f"{len(business_rejected):,}"
    )

    # ========================================================
    # 9. TRANSFORMATION
    # ========================================================

    print()
    print(
        "Bronze → Silver Transformation..."
    )

    silver_df = etl[
        "transform_to_silver"
    ](
        conn,
        accepted_df,
        table
    )

    print(
        f"Transformed records: "
        f"{len(silver_df):,}"
    )

    # ========================================================
    # 10. NOT NULL
    # ========================================================

    print()
    print(
        "NOT NULL Validation..."
    )

    (
        silver_df,
        null_rejected,
        null_reasons
    ) = etl[
        "validate_not_null"
    ](
        conn,
        silver_df,
        table
    )

    if not null_rejected.empty:

        count = etl[
            "quarantine_records"
        ](
            conn,
            null_rejected,
            table,
            batch_id,
            null_reasons
        )

        total_quarantined += count

    print(
        f"NOT NULL rejected: "
        f"{len(null_rejected):,}"
    )

    # ========================================================
    # 11. REFERENTIAL INTEGRITY
    # ========================================================

    print()
    print(
        "Referential Integrity Validation..."
    )

    (
        silver_df,
        ri_rejected,
        ri_reasons
    ) = etl[
        "validate_referential_integrity"
    ](
        conn,
        silver_df,
        table,
        policy
    )

    if not ri_rejected.empty:

        count = etl[
            "quarantine_records"
        ](
            conn,
            ri_rejected,
            table,
            batch_id,
            ri_reasons
        )

        total_quarantined += count

    print(
        f"RI rejected: "
        f"{len(ri_rejected):,}"
    )

    # ========================================================
    # 12. PRIMARY KEY
    # ========================================================

    print()
    print(
        "Primary Key Validation..."
    )

    (
        silver_df,
        pk_rejected,
        pk_reasons
    ) = etl[
        "validate_primary_key"
    ](
        conn,
        silver_df,
        table
    )

    if not pk_rejected.empty:

        count = etl[
            "quarantine_records"
        ](
            conn,
            pk_rejected,
            table,
            batch_id,
            pk_reasons
        )

        total_quarantined += count

    print(
        f"PK rejected: "
        f"{len(pk_rejected):,}"
    )

    # ========================================================
    # 13. SILVER MERGE
    # ========================================================

    print()
    print(
        "Merging accepted records into Silver..."
    )

    loaded = merge_to_silver(
        conn,
        silver_df,
        table,
        etl[
            "get_silver_columns"
        ]
    )

    print(
        f"✓ Silver MERGE loaded/updated: "
        f"{loaded:,}"
    )

    # ========================================================
    # 14. UPDATE WATERMARK
    # ========================================================
    #
    # Watermark is updated ONLY after the entire table
    # processing reaches the Silver stage.
    #
    # This prevents the watermark from moving before
    # extraction + validation + quarantine + Silver MERGE.
    #
    # ========================================================

    if extracted_count > 0:

        update_watermark(
            conn,
            table,
            watermark_at,
            watermark_key,
            batch_id
        )

    return {

        "table":
            table,

        "extracted":
            extracted_count,

        "loaded":
            loaded,

        "quarantined":
            total_quarantined,

        "watermark_at":
            watermark_at,

        "watermark_key":
            watermark_key
    }


# ============================================================
# RUN INCREMENTAL PIPELINE
# ============================================================

def run_incremental():

    start_time = datetime.now()

    print()
    print("=" * 70)
    print("ENTERPRISE BANKING - INCREMENTAL ETL")
    print("=" * 70)

    print(
        "1. Read Watermark        ✓"
    )

    print(
        "2. Extract Delta         ✓"
    )

    print(
        "3. Cleaning              ✓"
    )

    print(
        "4. Standardization       ✓"
    )

    print(
        "5. DQ Validation         ✓"
    )

    print(
        "6. Quarantine            ✓"
    )

    print(
        "7. Silver MERGE          ✓"
    )

    print(
        "8. Incremental DQ Recheck ✓"
    )

    print(
        "9. Update Watermark      ✓"
    )

    print("=" * 70)

    conn = None

    try:

        # ====================================================
        # DATABASE CONNECTION
        # ====================================================

        conn = get_connection()

        # ====================================================
        # LOAD EXISTING ETL FUNCTIONS
        # ====================================================

        etl = load_existing_etl_functions()

        # ====================================================
        # CREATE ETL BATCH
        # ====================================================

        print()
        print("=" * 70)

        print(
            "CREATING INCREMENTAL ETL BATCH"
        )

        print("=" * 70)

        batch_id = etl[
            "create_etl_batch"
        ](
            conn
        )

        print(
            f"✓ Incremental Batch ID: "
            f"{batch_id}"
        )

        # ====================================================
        # LOAD ACCEPTANCE POLICY
        # ====================================================

        print()
        print(
            "Loading Acceptance Policy..."
        )

        policy = etl[
            "load_acceptance_policy"
        ](
            conn
        )

        print(
            f"✓ Active policies loaded: "
            f"{len(policy)}"
        )

        # ====================================================
        # PROCESS ALL TABLES
        # ====================================================

        results = []

        total_extracted = 0
        total_loaded = 0
        total_quarantined = 0
        tables_with_delta = 0

        for table in TABLES:

            print()
            print("=" * 70)

            print(
                f"TABLE: {table}"
            )

            print("=" * 70)

            # ------------------------------------------------
            # READ WATERMARK
            # ------------------------------------------------

            watermark = get_watermark(
                conn,
                table
            )

            print(
                f"Table             : "
                f"{table}"
            )

            print(
                f"Watermark Column  : "
                f"{watermark['watermark_column']}"
            )

            print(
                f"Last Processed At : "
                f"{watermark['last_processed_at']}"
            )

            print(
                f"Last Processed Key: "
                f"{watermark['last_processed_key']}"
            )

            print(
                f"Last Batch ID     : "
                f"{watermark['last_batch_id']}"
            )

            # ------------------------------------------------
            # PROCESS TABLE
            # ------------------------------------------------

            result = process_table(
                conn,
                table,
                watermark,
                policy,
                batch_id,
                etl
            )

            results.append(
                result
            )

            total_extracted += (
                result["extracted"]
            )

            total_loaded += (
                result["loaded"]
            )

            total_quarantined += (
                result["quarantined"]
            )

            if result["extracted"] > 0:

                tables_with_delta += 1

        # ====================================================
        # INCREMENTAL DQ RECHECK
        # ====================================================

        print()
        print("=" * 70)

        print(
            "INCREMENTAL DQ RECHECK"
        )

        print("=" * 70)

        if total_loaded > 0:

            etl[
                "dq_recheck"
            ](
                conn,
                batch_id
            )

            print(
                "✓ Incremental DQ Recheck completed"
            )

        else:

            print(
                "✓ No Silver changes - "
                "DQ Recheck skipped"
            )

        # ====================================================
        # FINAL SUMMARY
        # ====================================================

        end_time = datetime.now()

        print()
        print("=" * 70)

        print(
            "INCREMENTAL ETL SUMMARY"
        )

        print("=" * 70)

        print(
            f"Batch ID              : "
            f"{batch_id}"
        )

        print(
            f"Tables processed      : "
            f"{len(TABLES)}"
        )

        print(
            f"Tables with delta     : "
            f"{tables_with_delta}"
        )

        print(
            f"Total delta rows      : "
            f"{total_extracted:,}"
        )

        print(
            f"Total Silver MERGE    : "
            f"{total_loaded:,}"
        )

        print(
            f"Total quarantined     : "
            f"{total_quarantined:,}"
        )

        print(
            f"Start time            : "
            f"{start_time}"
        )

        print(
            f"End time              : "
            f"{end_time}"
        )

        print(
            f"Duration              : "
            f"{end_time - start_time}"
        )

        print()
        print(
            "✓ Read Watermark completed."
        )

        print(
            "✓ Delta Extraction completed."
        )

        print(
            "✓ Cleaning completed."
        )

        print(
            "✓ Standardization completed."
        )

        print(
            "✓ DQ Validation completed."
        )

        print(
            "✓ Quarantine completed."
        )

        print(
            "✓ Silver MERGE completed."
        )

        print(
            "✓ DQ Recheck completed."
        )

        print(
            "✓ Watermarks updated."
        )

        print()
        print(
            "✓ Bronze was NOT modified."
        )

        print(
            "✓ Incremental ETL completed successfully."
        )

        print("=" * 70)

        return results

    except Exception as e:

        print()
        print("=" * 70)

        print(
            "✗ INCREMENTAL ETL FAILED"
        )

        print("=" * 70)

        print(
            f"ERROR: {str(e)}"
        )

        print("=" * 70)

        raise

    finally:

        if conn is not None:

            conn.close()

            print()
            print(
                "✓ Database connection closed"
            )


# ============================================================
# ENTRY POINT
# ============================================================

if __name__ == "__main__":

    run_incremental()