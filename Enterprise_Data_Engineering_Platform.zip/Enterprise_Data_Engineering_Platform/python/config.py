# ==========================================
# Dataset Size Configuration
# ==========================================

N_BRANCHES = 250
N_CUSTOMERS = 100_000
N_ACCOUNTS = 150_000
N_CARDS = 120_000
N_LOANS = 50_000
N_TRANSACTIONS = 500_000
N_CAMPAIGNS = 100
N_CUSTOMER_CAMPAIGNS = 300_000


# ==========================================
# Random Seed
# ==========================================

RANDOM_SEED = 42


# ==========================================
# Output Directories
# ==========================================

OUTPUT_DIR = "data/clean"


# ==========================================
# File Names
# ==========================================

CUSTOMERS_FILE = "customers.csv"
BRANCHES_FILE = "branches.csv"
ACCOUNTS_FILE = "accounts.csv"
TRANSACTIONS_FILE = "transactions.csv"
LOANS_FILE = "loans.csv"
CARDS_FILE = "cards.csv"
CAMPAIGNS_FILE = "campaigns.xlsx"
CUSTOMER_CAMPAIGNS_FILE = "customer_campaigns.csv"