import os
import random
import numpy as np
import pandas as pd
from faker import Faker

from python.config import RANDOM_SEED


# ==========================================
# Initialize Faker
# ==========================================

fake = Faker()
Faker.seed(RANDOM_SEED)
random.seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)


# ==========================================
# Create Output Directory
# ==========================================

def ensure_directory(path):
    """Create directory if it does not exist."""
    os.makedirs(path, exist_ok=True)


# ==========================================
# Save CSV
# ==========================================

def save_csv(df, output_path):
    """Save DataFrame as CSV."""
    df.to_csv(output_path, index=False, encoding="utf-8-sig")
    print(f"✅ Saved: {output_path}")


# ==========================================
# Save Excel
# ==========================================

def save_excel(df, output_path):
    """Save DataFrame as Excel."""
    df.to_excel(output_path, index=False)
    print(f"✅ Saved: {output_path}")