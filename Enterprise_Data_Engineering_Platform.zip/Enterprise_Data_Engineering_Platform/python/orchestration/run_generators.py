"""
Run All Dataset Generators
"""

from python.generators.generate_branches import generate_branches
from python.generators.generate_customers import generate_customers
from python.generators.generate_campaigns import generate_campaigns
from python.generators.generate_accounts import generate_accounts
from python.generators.generate_cards import generate_cards
from python.generators.generate_loans import generate_loans
from python.generators.generate_transactions import generate_transactions
from python.generators.generate_customer_campaigns import generate_customer_campaigns


def run_all_generators():
    """
    Run all dataset generators in dependency order.
    """

    print("=" * 70)
    print("STARTING DATASET GENERATION")
    print("=" * 70)

    # 1. Branches
    print("\n[1/8] Generating Branches...")
    generate_branches()

    # 2. Customers
    print("\n[2/8] Generating Customers...")
    generate_customers()

    # 3. Campaigns
    print("\n[3/8] Generating Campaigns...")
    generate_campaigns()

    # 4. Accounts
    print("\n[4/8] Generating Accounts...")
    generate_accounts()

    # 5. Cards
    print("\n[5/8] Generating Cards...")
    generate_cards()

    # 6. Loans
    print("\n[6/8] Generating Loans...")
    generate_loans()

    # 7. Transactions
    print("\n[7/8] Generating Transactions...")
    generate_transactions()

    # 8. Customer Campaigns
    print("\n[8/8] Generating Customer Campaigns...")
    generate_customer_campaigns()

    print("\n" + "=" * 70)
    print("ALL DATASETS GENERATED SUCCESSFULLY")
    print("=" * 70)


def main():
    run_all_generators()


if __name__ == "__main__":
    main()