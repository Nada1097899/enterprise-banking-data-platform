"""
Data Quality Validation Configuration
"""

# ==========================================
# Directories
# ==========================================

BRONZE_DIR = "data/bronze"
DQ_RESULTS_DIR = "data/data_quality"


# ==========================================
# Result Files
# ==========================================

DQ_RESULTS_FILE = "data_quality_results.csv"


# ==========================================
# Data Quality Dimensions
# ==========================================

DQ_DIMENSION_WEIGHTS = {
    "Completeness": 0.15,
    "Validity": 0.20,
    "Referential Integrity": 0.25,
    "Consistency": 0.15,
    "Uniqueness": 0.10,
    "Outlier Detection": 0.15
}


# ==========================================
# Quality Thresholds
# ==========================================

PASS_THRESHOLD = 0.95
WARNING_THRESHOLD = 0.90


# ==========================================
# Supported File Types
# ==========================================

SUPPORTED_FILE_TYPES = [
    ".csv",
    ".xlsx"
]


# ==========================================
# Dataset Configuration
# ==========================================

DATASETS = {
    "customers": "customers.csv",
    "accounts": "accounts.csv",
    "cards": "cards.csv",
    "loans": "loans.csv",
    "transactions": "transactions.csv",
    "campaigns": "campaigns.xlsx"
}


# ==========================================
# General Settings
# ==========================================

ROUND_DIGITS = 4