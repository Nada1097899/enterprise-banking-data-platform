"""
Data Quality Validation Runner
"""

import os
import pandas as pd

from .config import (
    BRONZE_DIR,
    DQ_RESULTS_DIR,
    DQ_RESULTS_FILE,
    DATASETS,
    DQ_DIMENSION_WEIGHTS,
    ROUND_DIGITS
)

from .loader import load_dataset

from .engine import (
    validate_all_datasets,
    results_to_dataframe
)

from .rules import (
    CompletenessRule,
    ValidityRule,
    ConsistencyRule,
    ReferentialIntegrityRule,
    UniquenessRule,
    OutlierRule
)


# ==========================================
# Rule Definitions
# ==========================================

customer_rules = [

    CompletenessRule(
        dataset="customers",
        column="email",
        rule_name="Missing Email",
        dimension="Completeness"
    ),

    ValidityRule(
        dataset="customers",
        column="gender",
        rule_name="Invalid Gender",
        dimension="Validity",
        allowed_values=[
            "Male",
            "Female",
            "Other"
        ]
    ),

    ConsistencyRule(
        dataset="customers",
        column="city",
        rule_name="Inconsistent City Case",
        dimension="Consistency",
        expected_values=None
    ),

    CompletenessRule(
        dataset="customers",
        column="annual_income",
        rule_name="Missing Annual Income",
        dimension="Completeness"
    ),

    OutlierRule(
        dataset="customers",
        column="annual_income",
        rule_name="Annual Income Outlier",
        dimension="Outlier Detection"
    ),

    UniquenessRule(
        dataset="customers",
        column="customer_id",
        rule_name="Duplicate Customer ID",
        dimension="Uniqueness"
    )
]


account_rules = [

    CompletenessRule(
        dataset="accounts",
        column="account_type",
        rule_name="Missing Account Type",
        dimension="Completeness"
    ),

    ValidityRule(
        dataset="accounts",
        column="currency",
        rule_name="Invalid Currency",
        dimension="Validity",
        allowed_values=[
            "USD",
            "EUR",
            "GBP",
            "AED",
            "EGP"
        ]
    ),

    ValidityRule(
        dataset="accounts",
        column="balance",
        rule_name="Invalid Balance",
        dimension="Validity",
        allowed_values=None
    ),

    ReferentialIntegrityRule(
        dataset="accounts",
        column="customer_id",
        rule_name="Invalid Customer Reference",
        dimension="Referential Integrity",
        reference_dataset="customers",
        reference_column="customer_id"
    ),

    UniquenessRule(
        dataset="accounts",
        column="account_id",
        rule_name="Duplicate Account ID",
        dimension="Uniqueness"
    ),

    OutlierRule(
        dataset="accounts",
        column="balance",
        rule_name="Balance Outlier",
        dimension="Outlier Detection"
    )
]


card_rules = [

    CompletenessRule(
        dataset="cards",
        column="card_number",
        rule_name="Missing Card Number",
        dimension="Completeness"
    ),

    ValidityRule(
        dataset="cards",
        column="card_type",
        rule_name="Invalid Card Type",
        dimension="Validity",
        allowed_values=[
            "Debit",
            "Credit"
        ]
    ),

    ValidityRule(
        dataset="cards",
        column="credit_limit",
        rule_name="Invalid Credit Limit",
        dimension="Validity",
        allowed_values=None
    ),

    ReferentialIntegrityRule(
        dataset="cards",
        column="account_id",
        rule_name="Invalid Account Reference",
        dimension="Referential Integrity",
        reference_dataset="accounts",
        reference_column="account_id"
    ),

    UniquenessRule(
        dataset="cards",
        column="card_number",
        rule_name="Duplicate Card Number",
        dimension="Uniqueness"
    ),

    OutlierRule(
        dataset="cards",
        column="credit_limit",
        rule_name="Credit Limit Outlier",
        dimension="Outlier Detection"
    )
]


loan_rules = [

    ValidityRule(
        dataset="loans",
        column="loan_type",
        rule_name="Invalid Loan Type",
        dimension="Validity",
        allowed_values=[
            "Personal",
            "Auto",
            "Mortgage",
            "Business"
        ]
    ),

    ValidityRule(
        dataset="loans",
        column="loan_amount",
        rule_name="Invalid Loan Amount",
        dimension="Validity",
        allowed_values=None
    ),

    ValidityRule(
        dataset="loans",
        column="monthly_installment",
        rule_name="Invalid Monthly Installment",
        dimension="Validity",
        allowed_values=None
    ),

    ReferentialIntegrityRule(
        dataset="loans",
        column="customer_id",
        rule_name="Invalid Customer Reference",
        dimension="Referential Integrity",
        reference_dataset="customers",
        reference_column="customer_id"
    ),

    UniquenessRule(
        dataset="loans",
        column="loan_id",
        rule_name="Duplicate Loan ID",
        dimension="Uniqueness"
    ),

    OutlierRule(
        dataset="loans",
        column="loan_amount",
        rule_name="Loan Amount Outlier",
        dimension="Outlier Detection"
    )
]


transaction_rules = [

    ValidityRule(
        dataset="transactions",
        column="transaction_type",
        rule_name="Invalid Transaction Type",
        dimension="Validity",
        allowed_values=[
            "Deposit",
            "Withdrawal",
            "Transfer",
            "Purchase",
            "Payment"
        ]
    ),

    ValidityRule(
        dataset="transactions",
        column="amount",
        rule_name="Invalid Transaction Amount",
        dimension="Validity",
        allowed_values=None
    ),

    CompletenessRule(
        dataset="transactions",
        column="merchant_name",
        rule_name="Missing Merchant Name",
        dimension="Completeness"
    ),

    ReferentialIntegrityRule(
        dataset="transactions",
        column="account_id",
        rule_name="Invalid Account Reference",
        dimension="Referential Integrity",
        reference_dataset="accounts",
        reference_column="account_id"
    ),

    UniquenessRule(
        dataset="transactions",
        column="transaction_id",
        rule_name="Duplicate Transaction ID",
        dimension="Uniqueness"
    ),

    OutlierRule(
        dataset="transactions",
        column="amount",
        rule_name="Transaction Amount Outlier",
        dimension="Outlier Detection"
    )
]


campaign_rules = [

    CompletenessRule(
        dataset="campaigns",
        column="campaign_name",
        rule_name="Missing Campaign Name",
        dimension="Completeness"
    ),

    ValidityRule(
        dataset="campaigns",
        column="campaign_type",
        rule_name="Invalid Campaign Type",
        dimension="Validity",
        allowed_values=[
            "Email",
            "SMS",
            "Social Media",
            "Push Notification"
        ]
    ),

    UniquenessRule(
        dataset="campaigns",
        column="campaign_id",
        rule_name="Duplicate Campaign ID",
        dimension="Uniqueness"
    )
]


# ==========================================
# Rules Registry
# ==========================================

RULES_BY_DATASET = {
    "customers": customer_rules,
    "accounts": account_rules,
    "cards": card_rules,
    "loans": loan_rules,
    "transactions": transaction_rules,
    "campaigns": campaign_rules
}


# ==========================================
# Load Bronze Datasets
# ==========================================

def load_bronze_datasets():
    """
    Load all Bronze datasets into memory.
    """

    datasets = {}

    for dataset_name, file_name in DATASETS.items():

        path = os.path.join(
            BRONZE_DIR,
            file_name
        )

        if not os.path.exists(path):
            print(
                f"⚠️ Bronze dataset not found: {path}"
            )
            continue

        extension = os.path.splitext(
            path
        )[1].lower()

        if extension == ".csv":
            df = pd.read_csv(path)

        elif extension == ".xlsx":
            df = pd.read_excel(path)

        else:
            print(
                f"⚠️ Unsupported file type: {path}"
            )
            continue

        datasets[dataset_name] = df

        print(
            f"Loaded Bronze Dataset -> "
            f"{dataset_name}: {len(df):,} rows"
        )

    return datasets


# ==========================================
# Calculate Overall Quality Score
# ==========================================

def calculate_overall_quality_score(
    results_df: pd.DataFrame
) -> float:
    """
    Calculate weighted overall data quality score.
    """

    if results_df.empty:
        return 0.0

    dimension_scores = {}

    for dimension in DQ_DIMENSION_WEIGHTS:

        dimension_df = results_df[
            results_df["dimension"] == dimension
        ]

        if dimension_df.empty:
            continue

        dimension_scores[dimension] = (
            dimension_df["quality_score"].mean()
        )

    weighted_score = 0.0
    total_weight = 0.0

    for dimension, weight in DQ_DIMENSION_WEIGHTS.items():

        if dimension not in dimension_scores:
            continue

        weighted_score += (
            dimension_scores[dimension] * weight
        )

        total_weight += weight

    if total_weight == 0:
        return 0.0

    return round(
        weighted_score / total_weight,
        ROUND_DIGITS
    )


# ==========================================
# Save Results
# ==========================================

def save_results(
    results_df: pd.DataFrame
):
    """
    Save Data Quality validation results.
    """

    os.makedirs(
        DQ_RESULTS_DIR,
        exist_ok=True
    )

    output_path = os.path.join(
        DQ_RESULTS_DIR,
        DQ_RESULTS_FILE
    )

    results_df.to_csv(
        output_path,
        index=False
    )

    print(
        f"\n✅ Data Quality Results Saved -> "
        f"{output_path}"
    )

    return output_path


# ==========================================
# Print Summary
# ==========================================

def print_summary(
    results_df: pd.DataFrame
):
    """
    Print validation summary.
    """

    if results_df.empty:
        print("No validation results found.")
        return

    print("\n" + "=" * 100)
    print("DATA QUALITY VALIDATION SUMMARY")
    print("=" * 100)

    print(
        f"Total Checks     : {len(results_df):,}"
    )

    print(
        f"Passed Checks    : "
        f"{(results_df['status'] == 'Passed').sum():,}"
    )

    print(
        f"Failed Checks    : "
        f"{(results_df['status'] == 'Failed').sum():,}"
    )

    print(
        f"Total Failed Rows: "
        f"{results_df['failed_records'].sum():,}"
    )

    overall_score = calculate_overall_quality_score(
        results_df
    )

    print(
        f"Overall Quality  : "
        f"{overall_score:.2%}"
    )

    print("\nResults by Dataset:")
    print("-" * 100)

    dataset_summary = (
        results_df
        .groupby("dataset")
        .agg(
            checks=("rule", "count"),
            failed_records=("failed_records", "sum"),
            avg_quality=("quality_score", "mean")
        )
        .reset_index()
    )

    for _, row in dataset_summary.iterrows():

        print(
            f"{row['dataset']:<20}"
            f"Checks: {int(row['checks']):<5}"
            f"Failed Rows: {int(row['failed_records']):<8}"
            f"Quality: {row['avg_quality']:.2%}"
        )

    print("=" * 100)


# ==========================================
# Main
# ==========================================

def main():

    print("\n" + "#" * 100)
    print("STARTING DATA QUALITY VALIDATION")
    print("#" * 100)

    # --------------------------------------
    # Load Bronze
    # --------------------------------------

    datasets = load_bronze_datasets()

    if not datasets:
        print(
            "❌ No Bronze datasets were found."
        )
        return

    # --------------------------------------
    # Run Validation
    # --------------------------------------

    results = validate_all_datasets(
        datasets=datasets,
        rules_by_dataset=RULES_BY_DATASET,
        reference_datasets=datasets
    )

    # --------------------------------------
    # Convert Results
    # --------------------------------------

    results_df = results_to_dataframe(
        results
    )

    # --------------------------------------
    # Save Results
    # --------------------------------------

    save_results(
        results_df
    )

    # --------------------------------------
    # Print Summary
    # --------------------------------------

    print_summary(
        results_df
    )

    print(
        "\n✅ DATA QUALITY VALIDATION "
        "COMPLETED SUCCESSFULLY\n"
    )


if __name__ == "__main__":
    main()