"""
Generate Customer Campaigns Dataset
"""

import os
import random

import pandas as pd

from python.utils import (
    fake,
    save_csv,
    ensure_directory
)

from python.config import (
    OUTPUT_DIR,
    CUSTOMER_CAMPAIGNS_FILE,
    CUSTOMERS_FILE,
    CAMPAIGNS_FILE,
    N_CUSTOMER_CAMPAIGNS
)

# ==========================================
# Constants
# ==========================================

RESPONSE_STATUS = [
    "Accepted",
    "Rejected",
    "No Response"
]

RESPONSE_WEIGHTS = [
    0.20,
    0.35,
    0.45
]

CAMPAIGN_CHANNELS = [
    "Email",
    "SMS",
    "Phone Call",
    "Mobile App",
    "Social Media"
]


# ==========================================
# Generate Customer Campaigns
# ==========================================

def generate_customer_campaigns():
    """
    Generate synthetic customer_campaigns clean dataset.
    """
    ensure_directory(OUTPUT_DIR)

    customers = pd.read_csv(
        os.path.join(
            OUTPUT_DIR,
            CUSTOMERS_FILE
        )
    )

    campaigns = pd.read_excel(
        os.path.join(
            OUTPUT_DIR,
            CAMPAIGNS_FILE
        )
    )

    # Convert to list of dicts for O(1) fast lookup
    customers_list = customers.to_dict(orient="records")
    campaigns_list = campaigns.to_dict(orient="records")

    today = pd.Timestamp.today().date()
    customer_campaigns = []

    for customer_campaign_id in range(1, N_CUSTOMER_CAMPAIGNS + 1):
        customer = random.choice(customers_list)
        campaign = random.choice(campaigns_list)

        campaign_start = pd.to_datetime(campaign["start_date"]).date()
        campaign_end = pd.to_datetime(campaign["end_date"]).date()
        customer_created = pd.to_datetime(customer["created_at"]).date()

        # Enforce Chronological Boundary: contact_date >= max(campaign_start, customer_created)
        start_date_bound = max(campaign_start, customer_created)

        # Fallback bounds ensuring contact_date <= today
        if start_date_bound > today or (campaign_end < start_date_bound):
            end_date_bound = today
        else:
            end_date_bound = min(campaign_end, today)

        if start_date_bound > end_date_bound:
            start_date_bound = end_date_bound

        # 1. Contact Date Generation (Clean Data <= today)
        contact_date = fake.date_between(
            start_date=start_date_bound,
            end_date=end_date_bound
        )

        # 2. Response Status & Conversion Flag Logic
        response_status = random.choices(
            RESPONSE_STATUS,
            weights=RESPONSE_WEIGHTS,
            k=1
        )[0]

        if response_status == "Accepted":
            # 90% chance of conversion if accepted
            conversion_flag = 1 if random.random() < 0.90 else 0
        else:
            conversion_flag = 0

        # 3. Channel selection
        channel = random.choice(CAMPAIGN_CHANNELS)

        # 4. Chronological Auditing Timestamps
        created_at = fake.date_time_between(
            start_date=contact_date,
            end_date="now"
        )

        updated_at = fake.date_time_between(
            start_date=created_at,
            end_date="now"
        )

        customer_campaign = {
            "customer_campaign_id": customer_campaign_id,
            "customer_id": customer["customer_id"],
            "campaign_id": campaign["campaign_id"],
            "contact_date": contact_date,
            "channel": channel,
            "response_status": response_status,
            "conversion_flag": conversion_flag,
            "created_at": created_at,
            "updated_at": updated_at
        }

        customer_campaigns.append(customer_campaign)

        if customer_campaign_id % 50000 == 0:
            print(f"{customer_campaign_id:,} customer_campaigns generated...")

    df = pd.DataFrame(customer_campaigns)

    output_path = os.path.join(
        OUTPUT_DIR,
        CUSTOMER_CAMPAIGNS_FILE
    )

    save_csv(
        df,
        output_path
    )

    print("=" * 60)
    print(f"Generated {len(df):,} Customer Campaign Records (Clean & Aligned)")
    print(f"Saved To : {output_path}")
    print("=" * 60)

    return df


# ==========================================
# Main
# ==========================================

def main():
    generate_customer_campaigns()


if __name__ == "__main__":
    main()