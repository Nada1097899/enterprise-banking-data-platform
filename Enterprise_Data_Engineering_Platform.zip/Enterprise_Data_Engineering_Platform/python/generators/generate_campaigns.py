"""
Generate Campaigns Dataset
"""

import os
import random

import pandas as pd

from python.utils import (
    fake,
    save_csv,
    ensure_directory,
    save_excel
)

from python.config import (
    OUTPUT_DIR,
    CAMPAIGNS_FILE,
    N_CAMPAIGNS
)


# ==========================================
# Constants
# ==========================================

CAMPAIGN_TYPES = [
    "Personal Loan",
    "Credit Card",
    "Mortgage",
    "Savings Account",
    "Investment",
    "Insurance"
]

CAMPAIGN_CHANNELS = [
    "Email",
    "SMS",
    "Phone Call",
    "Mobile App",
    "Social Media"
]

TARGET_SEGMENTS = [
    "Low Risk",
    "Medium Risk",
    "High Risk",
    "High Income",
    "Young Adults",
    "Business Owners",
    "Students"
]

CAMPAIGN_PREFIXES = [
    "Summer",
    "Winter",
    "Year-End",
    "Exclusive",
    "Growth",
    "Special Offer",
    "Premium"
]


# ==========================================
# Helper Functions
# ==========================================

def generate_campaign_name(campaign_type, campaign_id):
    """
    Generate a realistic campaign name.
    """
    prefix = random.choice(CAMPAIGN_PREFIXES)
    return f"{prefix} {campaign_type} Promo #{campaign_id}"


# ==========================================
# Generate Campaigns
# ==========================================

def generate_campaigns():
    """
    Generate synthetic marketing campaigns with proper date sequencing.
    """
    ensure_directory(OUTPUT_DIR)

    today = pd.Timestamp.today().date()
    campaigns = []

    for campaign_id in range(1, N_CAMPAIGNS + 1):

        campaign_type = random.choice(CAMPAIGN_TYPES)

        # Campaign Start Date
        start_date = fake.date_between(
            start_date="-3y",
            end_date="+30d"
        )

        # Campaign End Date must be >= Start Date
        end_date = fake.date_between(
            start_date=start_date,
            end_date=start_date + pd.Timedelta(days=180)
        )

        # Created At must be before or equal to Start Date
        created_at = fake.date_time_between(
            start_date="-3y",
            end_date=start_date
        )

        # Updated At must be >= Created At
        updated_at = fake.date_time_between(
            start_date=created_at,
            end_date="now"
        )

        # Dynamic Status
        if start_date > today:
            status = "Planned"
        elif end_date < today:
            status = "Completed"
        else:
            status = "Active"

        campaign = {
            "campaign_id": campaign_id,
            "campaign_name": generate_campaign_name(
                campaign_type,
                campaign_id
            ),
            "campaign_type": campaign_type,
            "target_segment": random.choice(TARGET_SEGMENTS),
            "channel": random.choice(CAMPAIGN_CHANNELS),
            "budget": random.randrange(
                5000,
                500001,
                1000
            ),
            "start_date": start_date,
            "end_date": end_date,
            "status": status,
            "created_at": created_at,
            "updated_at": updated_at
        }

        campaigns.append(campaign)

    df = pd.DataFrame(campaigns)

    output_path = os.path.join(
        OUTPUT_DIR,
        CAMPAIGNS_FILE
    )

    if output_path.endswith(".xlsx"):
        save_excel(df, output_path)
    else:
        save_csv(df, output_path)

    print("=" * 60)
    print(f"Generated {len(df):,} Campaign Records")
    print("Date Sequence Enforced")
    print(f"Saved To : {output_path}")
    print("=" * 60)

    return df


# ==========================================
# Main
# ==========================================

def main():
    generate_campaigns()


if __name__ == "__main__":
    main()