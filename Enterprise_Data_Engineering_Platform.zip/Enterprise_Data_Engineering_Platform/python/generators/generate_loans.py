"""
Generate Loans Dataset
"""

import os
import random
from dateutil.relativedelta import relativedelta

import pandas as pd

from python.utils import (
    fake,
    save_csv,
    ensure_directory
)

from python.config import (
    OUTPUT_DIR,
    LOANS_FILE,
    CUSTOMERS_FILE,
    BRANCHES_FILE
)

# ==========================================
# Constants
# ==========================================

LOAN_COVERAGE = 0.20

LOAN_TYPES = [
    "Personal",
    "Home",
    "Auto",
    "Business",
    "Education"
]

LOAN_TYPE_WEIGHTS = [
    0.45,
    0.20,
    0.15,
    0.10,
    0.10
]

INTEREST_RATES = {
    "Personal": (8.0, 18.0),
    "Home": (3.0, 8.0),
    "Auto": (4.0, 10.0),
    "Business": (6.0, 15.0),
    "Education": (2.0, 7.0)
}

LOAN_TERMS = {
    "Personal": [12, 24, 36, 48, 60],
    "Home": [120, 180, 240, 300, 360],
    "Auto": [24, 36, 48, 60, 72],
    "Business": [12, 24, 36, 48, 60],
    "Education": [24, 36, 48, 60]
}

LOAN_AMOUNT = {
    "Personal": (5000, 100000),
    "Home": (100000, 1000000),
    "Auto": (20000, 250000),
    "Business": (10000, 500000),
    "Education": (5000, 100000)
}

# ==========================================
# Helper Functions
# ==========================================

def generate_loan_amount(loan_type):
    minimum, maximum = LOAN_AMOUNT[loan_type]

    return random.randrange(
        minimum,
        maximum + 1000,
        1000
    )


def generate_interest_rate(loan_type):
    minimum, maximum = INTEREST_RATES[loan_type]

    return round(
        random.uniform(
            minimum,
            maximum
        ),
        2
    )


def generate_loan_term(loan_type):
    return random.choice(
        LOAN_TERMS[loan_type]
    )


def calculate_monthly_installment(
    loan_amount,
    annual_interest_rate,
    loan_term_months
):
    monthly_rate = (
        annual_interest_rate / 100
    ) / 12

    if monthly_rate == 0:
        return round(
            loan_amount / loan_term_months,
            2
        )

    installment = (
        loan_amount
        * monthly_rate
        * (1 + monthly_rate) ** loan_term_months
    ) / (
        (1 + monthly_rate) ** loan_term_months - 1
    )

    return round(
        installment,
        2
    )


def generate_end_date(start_date, loan_term_months):
    return (
        pd.Timestamp(start_date)
        + relativedelta(months=loan_term_months)
    ).date()


def calculate_remaining_balance(
    principal_amount,
    monthly_installment,
    annual_interest_rate,
    loan_term_months,
    start_date
):
    """
    Calculate remaining loan balance based on
    elapsed months since loan start.
    """

    today = pd.Timestamp.today().date()

    elapsed_months = (
        (today.year - start_date.year) * 12
        + (today.month - start_date.month)
    )

    elapsed_months = max(
        0,
        min(
            elapsed_months,
            loan_term_months
        )
    )

    monthly_rate = (
        annual_interest_rate / 100
    ) / 12

    if elapsed_months == 0:
        return round(
            principal_amount,
            2
        )

    if monthly_rate == 0:
        balance = (
            principal_amount
            - monthly_installment * elapsed_months
        )

    else:
        balance = (
            principal_amount
            * (1 + monthly_rate) ** elapsed_months
            - monthly_installment
            * (
                ((1 + monthly_rate) ** elapsed_months - 1)
                / monthly_rate
            )
        )

    return round(
        max(0, balance),
        2
    )

# ==========================================
# Generate Loans
# ==========================================

def generate_loans():

    ensure_directory(OUTPUT_DIR)

    # --------------------------------------
    # Load Customers
    # --------------------------------------

    customers = pd.read_csv(
        os.path.join(
            OUTPUT_DIR,
            CUSTOMERS_FILE
        )
    )

    # --------------------------------------
    # Load Branches
    # --------------------------------------

    branches = pd.read_csv(
        os.path.join(
            OUTPUT_DIR,
            BRANCHES_FILE
        )
    )

    # --------------------------------------
    # Select 20% of Customers
    # --------------------------------------

    customers = customers.sample(
        frac=LOAN_COVERAGE,
        random_state=42
    ).reset_index(drop=True)

    today = pd.Timestamp.today().date()

    loans = []

    # ======================================
    # Generate One Loan Per Selected Customer
    # ======================================

    for loan_id, customer in enumerate(
        customers.itertuples(index=False),
        start=1
    ):

        loan_type = random.choices(
            LOAN_TYPES,
            weights=LOAN_TYPE_WEIGHTS,
            k=1
        )[0]

        principal_amount = generate_loan_amount(
            loan_type
        )

        interest_rate = generate_interest_rate(
            loan_type
        )

        loan_term = generate_loan_term(
            loan_type
        )

        monthly_installment = calculate_monthly_installment(
            principal_amount,
            interest_rate,
            loan_term
        )

        # ----------------------------------
        # Select Branch
        # ----------------------------------

        branch_id = random.choice(
            branches["branch_id"].tolist()
        )

        # ----------------------------------
        # Start Date
        # ----------------------------------

        created_at_customer = pd.to_datetime(
            customer.created_at
        ).date()

        start_date = fake.date_between(
            start_date=created_at_customer,
            end_date="today"
        )

        # ----------------------------------
        # End Date
        # ----------------------------------

        end_date = generate_end_date(
            start_date,
            loan_term
        )

        # ----------------------------------
        # Loan Status
        # ----------------------------------

        if end_date < today:

            loan_status = random.choices(
                ["Closed", "Defaulted"],
                weights=[0.90, 0.10],
                k=1
            )[0]

        else:

            loan_status = "Active"

        # ----------------------------------
        # Remaining Balance
        # ----------------------------------

        remaining_balance = calculate_remaining_balance(
            principal_amount,
            monthly_installment,
            interest_rate,
            loan_term,
            start_date
        )

        # ----------------------------------
        # Audit Timestamps
        # ----------------------------------

        created_at = fake.date_time_between(
            start_date=start_date,
            end_date="now"
        )

        updated_at = fake.date_time_between(
            start_date=created_at,
            end_date="now"
        )

        # ----------------------------------
        # Loan Record
        # ----------------------------------

        loan = {

            "loan_id": loan_id,

            "customer_id": customer.customer_id,

            "branch_id": branch_id,

            "loan_type": loan_type,

            "principal_amount": principal_amount,

            "interest_rate": interest_rate,

            "loan_term_months": loan_term,

            "monthly_installment": monthly_installment,

            "remaining_balance": remaining_balance,

            "loan_status": loan_status,

            "start_date": start_date,

            "end_date": end_date,

            "created_at": created_at,

            "updated_at": updated_at
        }

        loans.append(loan)

    # ======================================
    # Create DataFrame
    # ======================================

    df = pd.DataFrame(loans)

    # ======================================
    # Save
    # ======================================

    output_path = os.path.join(
        OUTPUT_DIR,
        LOANS_FILE
    )

    save_csv(
        df,
        output_path
    )

    print("=" * 60)
    print(
        f"Generated {len(df):,} Loan Records"
    )
    print(
        f"Saved To : {output_path}"
    )
    print("=" * 60)

    return df


# ==========================================
# Main
# ==========================================

def main():
    generate_loans()


if __name__ == "__main__":
    main()