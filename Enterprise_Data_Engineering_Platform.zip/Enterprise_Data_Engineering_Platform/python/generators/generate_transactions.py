"""
Generate Transactions Dataset
"""

import os
import random

import pandas as pd

from python.utils import (
    fake,
    save_csv,
    ensure_directory
)

from python.config import (
    OUTPUT_DIR,
    TRANSACTIONS_FILE,
    ACCOUNTS_FILE,
    N_TRANSACTIONS
)


# ==========================================
# Constants
# ==========================================

TRANSACTION_TYPES = [
    "Deposit",
    "Withdrawal",
    "Transfer",
    "Purchase",
    "Payment"
]

TRANSACTION_TYPE_WEIGHTS = [
    0.20,
    0.15,
    0.25,
    0.30,
    0.10
]

CHANNELS = [
    "ATM",
    "Branch",
    "Mobile App",
    "Internet Banking",
    "POS"
]

STATUS = [
    "Completed",
    "Failed",
    "Reversed"
]

STATUS_WEIGHTS = [
    0.95,
    0.03,
    0.02
]

MERCHANTS = {
    "Retail": [
        "Amazon",
        "Carrefour",
        "Walmart",
        "IKEA"
    ],
    "Restaurant": [
        "McDonald's",
        "KFC",
        "Starbucks",
        "Pizza Hut"
    ],
    "Fuel": [
        "Shell",
        "Total",
        "BP"
    ],
    "Healthcare": [
        "Pharmacy",
        "Hospital"
    ],
    "Travel": [
        "Uber",
        "Airbnb",
        "Booking"
    ],
    "Utilities": [
        "Electricity",
        "Water",
        "Internet"
    ]
}


# ==========================================
# Helper Functions
# ==========================================

def generate_amount(transaction_type):
    """
    Generate realistic transaction amount based on transaction type.
    """
    if transaction_type == "Deposit":
        return random.randrange(100, 10001, 10)

    elif transaction_type == "Withdrawal":
        return random.randrange(20, 5001, 10)

    elif transaction_type == "Transfer":
        return random.randrange(100, 50001, 10)

    elif transaction_type == "Purchase":
        return random.randrange(5, 5001, 5)

    elif transaction_type == "Payment":
        return random.randrange(20, 10001, 10)

    return 0


def generate_merchant():
    """
    Generate merchant category and merchant name.
    """
    category = random.choice(list(MERCHANTS.keys()))
    merchant = random.choice(MERCHANTS[category])
    return category, merchant


def generate_channel(transaction_type):
    """
    Generate realistic channel based on transaction type.
    """
    if transaction_type == "Withdrawal":
        return random.choices(
            ["ATM", "Branch"],
            weights=[0.85, 0.15],
            k=1
        )[0]

    elif transaction_type == "Deposit":
        return random.choices(
            ["ATM", "Branch", "Mobile App"],
            weights=[0.20, 0.60, 0.20],
            k=1
        )[0]

    elif transaction_type == "Purchase":
        return random.choices(
            ["POS", "Internet Banking"],
            weights=[0.80, 0.20],
            k=1
        )[0]

    elif transaction_type == "Transfer":
        return random.choices(
            ["Mobile App", "Internet Banking", "Branch"],
            weights=[0.50, 0.40, 0.10],
            k=1
        )[0]

    elif transaction_type == "Payment":
        return random.choices(
            ["Internet Banking", "Mobile App"],
            weights=[0.60, 0.40],
            k=1
        )[0]

    else:
        return random.choice(CHANNELS)


def generate_audit_dates(transaction_date):
    """
    Generate created_at and updated_at timestamps.
    """
    created_at = fake.date_time_between(
        start_date=transaction_date,
        end_date="now"
    )

    updated_at = fake.date_time_between(
        start_date=created_at,
        end_date="now"
    )

    return created_at, updated_at


# ==========================================
# Generate Transactions
# ==========================================

def generate_transactions():
    """
    Generate synthetic transactions dataset aligned with account lifecycle rules.
    """
    ensure_directory(OUTPUT_DIR)

    accounts_df = pd.read_csv(
        os.path.join(
            OUTPUT_DIR,
            ACCOUNTS_FILE
        )
    )

    accounts_list = accounts_df.to_dict(orient="records")
    today = pd.Timestamp.today().date()
    transactions = []

    for transaction_id in range(1, N_TRANSACTIONS + 1):
        account = random.choice(accounts_list)

        transaction_type = random.choices(
            TRANSACTION_TYPES,
            weights=TRANSACTION_TYPE_WEIGHTS,
            k=1
        )[0]

        amount = generate_amount(transaction_type)

        if transaction_type in ("Deposit", "Withdrawal"):
            merchant_category = None
            merchant_name = None
        else:
            merchant_category, merchant_name = generate_merchant()

        status = random.choices(
            STATUS,
            weights=STATUS_WEIGHTS,
            k=1
        )[0]

        if status == "Failed":
            amount = 0

        # Enforce Account Lifecycle Rules
        account_opened_date = pd.to_datetime(account["opened_date"]).date()

        if account.get("status") == "Closed" and pd.notna(account.get("closed_date")):
            transaction_end_date = pd.to_datetime(account["closed_date"]).date()
        else:
            transaction_end_date = today

        # Fallback safety check for valid date window
        if account_opened_date > transaction_end_date:
            account_opened_date = transaction_end_date

        transaction_date = fake.date_between(
            start_date=account_opened_date,
            end_date=transaction_end_date
        )

        created_at, updated_at = generate_audit_dates(transaction_date)

        transaction = {
            "transaction_id": transaction_id,
            "account_id": account["account_id"],
            "transaction_date": transaction_date,
            "transaction_type": transaction_type,
            "amount": amount,
            "currency": account["currency"],
            "merchant_name": merchant_name,
            "merchant_category": merchant_category,
            "channel": generate_channel(transaction_type),
            "status": status,
            "created_at": created_at,
            "updated_at": updated_at
        }

        transactions.append(transaction)

        if transaction_id % 50000 == 0:
            print(f"{transaction_id:,} transactions generated...")

    df = pd.DataFrame(transactions)

    output_path = os.path.join(
        OUTPUT_DIR,
        TRANSACTIONS_FILE
    )

    save_csv(
        df,
        output_path
    )

    print("=" * 60)
    print(f"Generated {len(df):,} Transaction Records (Lifecycle Aligned)")
    print(f"Saved To : {output_path}")
    print("=" * 60)

    return df


# ==========================================
# Main
# ==========================================

def main():
    generate_transactions()


if __name__ == "__main__":
    main()