"""
Generate Customers Dataset
"""

import os
import random
import string

import pandas as pd

from python.utils import (
    fake,
    save_csv,
    ensure_directory
)

from python.config import (
    N_CUSTOMERS,
    OUTPUT_DIR,
    CUSTOMERS_FILE
)


# ==========================================
# Constants
# ==========================================

GENDERS = [
    "Male",
    "Female"
]

LOCATIONS = {
    "USA": ["New York"],
    "Canada": ["Toronto"],
    "Germany": ["Berlin"],
    "France": ["Paris"],
    "United Kingdom": ["London"],
    "Netherlands": ["Amsterdam"],
    "Australia": ["Sydney"],
    "UAE": ["Dubai"],
    "Saudi Arabia": ["Riyadh"],
    "Singapore": ["Singapore"]
}

OCCUPATIONS = [
    "Engineer",
    "Doctor",
    "Teacher",
    "Lawyer",
    "Accountant",
    "Software Developer",
    "Business Analyst",
    "Sales Manager",
    "Marketing Specialist",
    "Consultant",
    "Nurse",
    "Architect",
    "Student",
    "Retired",
    "Business Owner"
]

RISK_SEGMENTS = [
    "Low",
    "Medium",
    "High"
]

RISK_WEIGHTS = [
    0.60,
    0.30,
    0.10
]


# ==========================================
# Unique Value Tracking
# ==========================================

USED_NATIONAL_IDS = set()
USED_EMAILS = set()
USED_PHONES = set()


# ==========================================
# Helper Functions
# ==========================================

def generate_national_id():
    """
    Generate a unique national ID.
    """
    while True:
        national_id = "".join(
            random.choices(
                string.digits,
                k=14
            )
        )

        if national_id not in USED_NATIONAL_IDS:
            USED_NATIONAL_IDS.add(national_id)
            return national_id


def generate_phone():
    """
    Generate a unique international phone number.
    """
    while True:
        country_code = random.choice([
            "+1",
            "+44",
            "+49",
            "+61",
            "+971",
            "+966",
            "+65"
        ])

        number = "".join(
            random.choices(
                string.digits,
                k=10
            )
        )

        phone = f"{country_code}{number}"

        if phone not in USED_PHONES:
            USED_PHONES.add(phone)
            return phone


def generate_email(first_name, last_name, customer_id):
    """
    Generate a unique email.
    """
    domains = [
        "gmail.com",
        "outlook.com",
        "hotmail.com",
        "yahoo.com",
        "enterprise.com"
    ]

    while True:
        domain = random.choice(domains)

        email = (
            f"{first_name.lower()}."
            f"{last_name.lower()}."
            f"{customer_id}@{domain}"
        )

        if email not in USED_EMAILS:
            USED_EMAILS.add(email)
            return email


def generate_income():
    """
    Generate annual income in steps of 500.
    """
    return random.randrange(20000, 300001, 500)


def generate_risk_segment():
    """
    Generate customer risk segment.
    """
    return random.choices(
        RISK_SEGMENTS,
        weights=RISK_WEIGHTS,
        k=1
    )[0]


# ==========================================
# Generate Customers
# ==========================================

def generate_customers():
    """
    Generate synthetic customers dataset.
    """
    ensure_directory(OUTPUT_DIR)

    customers = []

    for customer_id in range(1, N_CUSTOMERS + 1):
        first_name = fake.first_name()
        last_name = fake.last_name()

        country = random.choice(list(LOCATIONS.keys()))
        city = random.choice(LOCATIONS[country])

        created_at = fake.date_time_between(
            start_date="-3y",
            end_date="-1y"
        )
        updated_at = fake.date_time_between(
            start_date=created_at,
            end_date="now"
        )

        customer = {
            "customer_id": customer_id,
            "first_name": first_name,
            "last_name": last_name,
            "gender": random.choice(GENDERS),
            "date_of_birth": fake.date_of_birth(
                minimum_age=18,
                maximum_age=80
            ),
            "email": generate_email(
                first_name,
                last_name,
                customer_id
            ),
            "phone": generate_phone(),
            "national_id": generate_national_id(),
            "city": city,
            "country": country,
            "occupation": random.choice(OCCUPATIONS),
            "annual_income": generate_income(),
            "risk_segment": generate_risk_segment(),
            "created_at": created_at,
            "updated_at": updated_at
        }

        customers.append(customer)

    df = pd.DataFrame(customers)

    output_path = os.path.join(
        OUTPUT_DIR,
        CUSTOMERS_FILE
    )

    save_csv(
        df,
        output_path
    )

    print("=" * 60)
    print(f"Generated {len(df):,} Customer Records (Unique Checks Passed)")
    print(f"Saved To : {output_path}")
    print("=" * 60)

    return df


# ==========================================
# Main
# ==========================================

def main():
    generate_customers()


if __name__ == "__main__":
    main()