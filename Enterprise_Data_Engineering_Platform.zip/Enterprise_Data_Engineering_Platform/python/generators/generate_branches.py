"""
Generate Branches Dataset
"""

import os
import random
import pandas as pd

from python.utils import (
    fake,
    save_csv,
    ensure_directory
)

from python.config import (
    N_BRANCHES,
    OUTPUT_DIR,
    BRANCHES_FILE
)


# ==========================================
# Constants
# ==========================================

BRANCH_CITIES = [
    "Cairo",
    "Giza",
    "Alexandria",
    "Mansoura",
    "Tanta",
    "Zagazig",
    "Asyut",
    "Luxor",
    "Aswan",
    "Suez"
]

REGIONS = {
    "Cairo": "Greater Cairo",
    "Giza": "Greater Cairo",
    "Alexandria": "North Coast",
    "Mansoura": "Delta",
    "Tanta": "Delta",
    "Zagazig": "Delta",
    "Asyut": "Upper Egypt",
    "Luxor": "Upper Egypt",
    "Aswan": "Upper Egypt",
    "Suez": "Canal"
}

BRANCH_STATUS = [
    "Active",
    "Closed"
]


# ==========================================
# Generate Branches
# ==========================================

def generate_branches():
    """
    Generate synthetic branch data with proper date sequencing.
    """

    ensure_directory(OUTPUT_DIR)

    branches = []

    for branch_id in range(1, N_BRANCHES + 1):

        city = random.choice(BRANCH_CITIES)

        # Logical Date Sequencing
        opened_date = fake.date_between(
            start_date="-20y",
            end_date="-1y"
        )
        created_at = fake.date_time_between(
            start_date=opened_date,
            end_date="now"
        )
        updated_at = fake.date_time_between(
            start_date=created_at,
            end_date="now"
        )

        branch = {
            "branch_id": branch_id,
            "branch_code": f"BR{branch_id:04}",
            "branch_name": f"{city} Branch",
            "city": city,
            "region": REGIONS[city],
            "manager_name": fake.name(),
            "phone": fake.phone_number(),
            "opened_date": opened_date,
            "status": random.choice(BRANCH_STATUS),
            "created_at": created_at,
            "updated_at": updated_at
        }

        branches.append(branch)

    df = pd.DataFrame(branches)

    output_path = os.path.join(
        OUTPUT_DIR,
        BRANCHES_FILE
    )

    save_csv(df, output_path)

    print("=" * 60)
    print(f"Generated {len(df):,} Branch Records (Date Sequence Enforced)")
    print(f"Saved To : {output_path}")
    print("=" * 60)

    return df


# ==========================================
# Main
# ==========================================

def main():
    generate_branches()


if __name__ == "__main__":
    main()