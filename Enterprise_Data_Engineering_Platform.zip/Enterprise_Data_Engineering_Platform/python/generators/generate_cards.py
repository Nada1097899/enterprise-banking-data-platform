"""
Generate Cards Dataset
"""

import os
import random
import string
from datetime import timedelta

import pandas as pd

from python.utils import (
    fake,
    save_csv,
    ensure_directory
)

from python.config import (
    OUTPUT_DIR,
    CARDS_FILE,
    ACCOUNTS_FILE
)


# ==========================================
# Constants
# ==========================================

CARD_TYPES = [
    "Debit",
    "Credit",
    "Prepaid"
]

CARD_TYPE_WEIGHTS = [
    0.70,
    0.25,
    0.05
]

CARD_NETWORKS = [
    "Visa",
    "Mastercard",
    "American Express"
]

CARD_NETWORK_WEIGHTS = [
    0.55,
    0.40,
    0.05
]

CARD_COVERAGE = 0.90


# ==========================================
# Unique Value Tracking
# ==========================================

USED_CARD_NUMBERS = set()


# ==========================================
# Helper Functions
# ==========================================

def generate_card_number():
    """
    Generate a unique 16-digit card number.
    """
    while True:
        card_number = "".join(
            random.choices(
                string.digits,
                k=16
            )
        )

        if card_number not in USED_CARD_NUMBERS:
            USED_CARD_NUMBERS.add(card_number)
            return card_number


def generate_credit_limit(card_type):
    """
    Generate credit limit based on card type.
    """
    if card_type == "Credit":
        return random.randrange(
            1000,
            50001,
            500
        )
    return 0


def generate_available_limit(credit_limit):
    """
    Generate available credit limit.
    """
    if credit_limit == 0:
        return 0

    return random.randrange(
        0,
        credit_limit + 500,
        500
    )


def generate_expiry_date(issued_date):
    """
    Generate card expiry date exactly 3 to 5 years after issued_date.
    """
    return issued_date + timedelta(days=365 * random.randint(3, 5))


# ==========================================
# Generate Cards
# ==========================================

def generate_cards():
    """
    Generate synthetic cards dataset with proper date and status logic.
    """
    ensure_directory(OUTPUT_DIR)

    accounts = pd.read_csv(
        os.path.join(
            OUTPUT_DIR,
            ACCOUNTS_FILE
        )
    )

    # Select 90% of accounts
    accounts = accounts.sample(
        frac=CARD_COVERAGE,
        random_state=42
    ).reset_index(drop=True)

    cards = []
    today_date = pd.Timestamp.today().date()

    for card_id, account in enumerate(accounts.itertuples(index=False), start=1):
        # 1. Ensure card issued date is after account opened date
        opened_date = pd.to_datetime(account.opened_date).date()
        issued_date = fake.date_between(
            start_date=opened_date,
            end_date="today"
        )

        card_type = random.choices(
            CARD_TYPES,
            weights=CARD_TYPE_WEIGHTS,
            k=1
        )[0]

        credit_limit = generate_credit_limit(card_type)
        available_limit = generate_available_limit(credit_limit)

        expiry_date = generate_expiry_date(issued_date)

        # Dynamic Status Logic based on Expiry Date
        if expiry_date < today_date:
            status = "Expired"
        else:
            status = random.choices(
                ["Active", "Blocked"],
                weights=[0.95, 0.05],
                k=1
            )[0]

        created_at = fake.date_time_between(
            start_date=issued_date,
            end_date="now"
        )

        updated_at = fake.date_time_between(
            start_date=created_at,
            end_date="now"
        )

        card = {
            "card_id": card_id,
            "account_id": account.account_id,
            "card_number": generate_card_number(),
            "card_type": card_type,
            "network": random.choices(
                CARD_NETWORKS,
                weights=CARD_NETWORK_WEIGHTS,
                k=1
            )[0],
            "issued_date": issued_date,
            "expiry_date": expiry_date,
            "credit_limit": credit_limit,
            "available_limit": available_limit,
            "status": status,
            "created_at": created_at,
            "updated_at": updated_at
        }

        cards.append(card)

    df = pd.DataFrame(cards)

    output_path = os.path.join(
        OUTPUT_DIR,
        CARDS_FILE
    )

    save_csv(
        df,
        output_path
    )

    print("=" * 60)
    print(f"Generated {len(df):,} Card Records (Enforced Expiry Status)")
    print(f"Saved To : {output_path}")
    print("=" * 60)

    return df


# ==========================================
# Main
# ==========================================

def main():
    generate_cards()


if __name__ == "__main__":
    main()