"""
Generate Accounts Dataset
"""

import os
import random

import pandas as pd

from python.utils import (
    fake,
    save_csv,
    ensure_directory
)

from python.config import (
    N_ACCOUNTS,
    OUTPUT_DIR,
    ACCOUNTS_FILE,
    CUSTOMERS_FILE,
    BRANCHES_FILE
)


# ==========================================
# Constants
# ==========================================

ACCOUNT_TYPES = [
    "Savings",
    "Current",
    "Salary",
    "Business"
]

CURRENCIES = [
    "USD",
    "EUR",
    "GBP",
    "AED",
    "SAR"
]

ACCOUNT_STATUS = [
    "Active",
    "Dormant",
    "Closed"
]

STATUS_WEIGHTS = [
    0.80,
    0.15,
    0.05
]


# ==========================================
# Unique Value Tracking
# ==========================================

USED_ACCOUNT_NUMBERS = set()


# ==========================================
# Helper Functions
# ==========================================

def generate_account_number():
    """
    Generate a unique bank account number.
    """
    while True:
        account_number = "".join(
            random.choices(
                "0123456789",
                k=12
            )
        )

        if account_number not in USED_ACCOUNT_NUMBERS:
            USED_ACCOUNT_NUMBERS.add(account_number)
            return account_number


def generate_balance():
    """
    Generate account balance in steps of 100.
    """
    return random.randrange(
        0,
        500001,
        100
    )


# ==========================================
# Generate Accounts
# ==========================================

def generate_accounts():
    """
    Generate synthetic accounts dataset.
    """
    ensure_directory(OUTPUT_DIR)

    customers = pd.read_csv(
        os.path.join(
            OUTPUT_DIR,
            CUSTOMERS_FILE
        )
    )

    branches = pd.read_csv(
        os.path.join(
            OUTPUT_DIR,
            BRANCHES_FILE
        )
    )

    customer_ids = customers["customer_id"].tolist()
    branch_ids = branches["branch_id"].tolist()

    accounts = []

    for account_id in range(1, N_ACCOUNTS + 1):
        opened_date = fake.date_between(
            start_date="-10y",
            end_date="today"
        )

        status = random.choices(
            ACCOUNT_STATUS,
            weights=STATUS_WEIGHTS,
            k=1
        )[0]

        closed_date = None
        if status == "Closed":
            closed_date = fake.date_between(
                start_date=opened_date,
                end_date="today"
            )

        created_at = fake.date_time_between(
            start_date=opened_date,
            end_date="now"
        )

        updated_at = fake.date_time_between(
            start_date=created_at,
            end_date="now"
        )

        account = {
            "account_id": account_id,
            "customer_id": random.choice(customer_ids),
            "branch_id": random.choice(branch_ids),
            "account_number": generate_account_number(),
            "account_type": random.choice(ACCOUNT_TYPES),
            "currency": random.choice(CURRENCIES),
            "balance": generate_balance(),
            "status": status,
            "opened_date": opened_date,
            "closed_date": closed_date,
            "created_at": created_at,
            "updated_at": updated_at
        }

        accounts.append(account)

    df = pd.DataFrame(accounts)

    output_path = os.path.join(
        OUTPUT_DIR,
        ACCOUNTS_FILE
    )

    save_csv(
        df,
        output_path
    )

    print("=" * 60)
    print(f"Generated {len(df):,} Account Records")
    print(f"Saved To : {output_path}")
    print("=" * 60)

    return df


# ==========================================
# Main
# ==========================================

def main():
    generate_accounts()


if __name__ == "__main__":
    main()