# Dataset Specification

| Table | Estimated Rows |
|--------|---------------:|
| Customers | 100,000 |
| Accounts | 150,000 |
| Transactions | 1,000,000 |
| Branches | 100 |
| Loans | 30,000 |
| Cards | 120,000 |
| Campaigns | 50 |
| Customer_Campaigns | 300,000 |