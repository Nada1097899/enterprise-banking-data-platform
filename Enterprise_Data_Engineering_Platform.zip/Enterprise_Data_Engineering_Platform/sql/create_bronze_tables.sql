/*
===============================================================================
Script Name : create_bronze_tables.sql
Purpose     : Create Raw Tables in Bronze Layer
Database    : EnterpriseBankingDW
===============================================================================
*/

USE EnterpriseBankingDW;
GO

-- ============================================================================
-- 1. Table: Customers
-- ============================================================================
IF OBJECT_ID('bronze.customers', 'U') IS NOT NULL
    DROP TABLE bronze.customers;
GO

CREATE TABLE bronze.customers
(
    customer_id     INT IDENTITY(1,1) NOT NULL,
    first_name      VARCHAR(50) NOT NULL,
    last_name       VARCHAR(50) NOT NULL,
    gender          VARCHAR(10) NULL,
    date_of_birth   DATE NULL,
    email           VARCHAR(100) NULL,
    phone           VARCHAR(20) NULL,
    national_id     VARCHAR(20) NOT NULL,
    city            VARCHAR(50) NULL,
    country         VARCHAR(50) NULL,
    occupation      VARCHAR(100) NULL,
    annual_income   DECIMAL(18,2) NULL,
    risk_segment    VARCHAR(20) NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NULL
);
GO

-- ============================================================================
-- 2. Table: Accounts
-- ============================================================================
IF OBJECT_ID('bronze.accounts', 'U') IS NOT NULL
    DROP TABLE bronze.accounts;
GO

CREATE TABLE bronze.accounts
(
    account_id      INT IDENTITY(1,1) NOT NULL,
    customer_id     INT NOT NULL,
    branch_id       INT NOT NULL,
    account_number  VARCHAR(30) NOT NULL,
    account_type    VARCHAR(20) NOT NULL,
    balance         DECIMAL(18,2) NOT NULL,
    currency        VARCHAR(3) NOT NULL,
    status          VARCHAR(20) NOT NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
GO

-- ============================================================================
-- 3. Table: Transactions
-- ============================================================================
IF OBJECT_ID('bronze.transactions', 'U') IS NOT NULL
    DROP TABLE bronze.transactions;
GO

CREATE TABLE bronze.transactions
(
    transaction_id   INT IDENTITY(1,1) NOT NULL,
    account_id       INT NOT NULL,
    transaction_type VARCHAR(20) NOT NULL,
    amount           DECIMAL(18,2) NOT NULL,
    transaction_date DATETIME NOT NULL,
    merchant_name    VARCHAR(100) NULL,
    channel          VARCHAR(20) NOT NULL
);
GO

-- ============================================================================
-- 4. Table: Branches
-- ============================================================================
IF OBJECT_ID('bronze.branches', 'U') IS NOT NULL
    DROP TABLE bronze.branches;
GO

CREATE TABLE bronze.branches
(
    branch_id    INT IDENTITY(1,1) NOT NULL,
    branch_name  VARCHAR(100) NOT NULL,
    branch_code  VARCHAR(10) NOT NULL,
    city         VARCHAR(50) NOT NULL,
    manager_name VARCHAR(100) NULL
);
GO

-- ============================================================================
-- 5. Table: Loans
-- ============================================================================
IF OBJECT_ID('bronze.loans', 'U') IS NOT NULL
    DROP TABLE bronze.loans;
GO

CREATE TABLE bronze.loans
(
    loan_id       INT IDENTITY(1,1) NOT NULL,
    customer_id   INT NOT NULL,
    branch_id     INT NOT NULL,
    loan_type     VARCHAR(30) NOT NULL,
    loan_amount   DECIMAL(18,2) NOT NULL,
    interest_rate DECIMAL(5,2) NOT NULL,
    term_months   INT NOT NULL,
    start_date    DATE NOT NULL,
    status        VARCHAR(20) NOT NULL
);
GO

-- ============================================================================
-- 6. Table: Cards
-- ============================================================================
IF OBJECT_ID('bronze.cards', 'U') IS NOT NULL
    DROP TABLE bronze.cards;
GO

CREATE TABLE bronze.cards
(
    card_id     INT IDENTITY(1,1) NOT NULL,
    account_id  INT NOT NULL,
    card_number VARCHAR(20) NOT NULL,
    card_type   VARCHAR(20) NOT NULL,
    expiry_date DATE NOT NULL,
    status      VARCHAR(20) NOT NULL
);
GO

-- ============================================================================
-- 7. Table: Campaigns
-- ============================================================================
IF OBJECT_ID('bronze.campaigns', 'U') IS NOT NULL
    DROP TABLE bronze.campaigns;
GO

CREATE TABLE bronze.campaigns
(
    campaign_id    INT IDENTITY(1,1) NOT NULL,
    campaign_name  VARCHAR(100) NOT NULL,
    target_segment VARCHAR(50) NULL,
    start_date     DATE NOT NULL,
    end_date       DATE NULL
);
GO

-- ============================================================================
-- 8. Table: Customer_Campaigns
-- ============================================================================
IF OBJECT_ID('bronze.customer_campaigns', 'U') IS NOT NULL
    DROP TABLE bronze.customer_campaigns;
GO

CREATE TABLE bronze.customer_campaigns
(
    customer_campaign_id INT IDENTITY(1,1) NOT NULL,
    customer_id          INT NOT NULL,
    campaign_id          INT NOT NULL,
    response_status      VARCHAR(20) NULL
);
GO


------------------------------------------------------------
-- Bronze Layer
-- Table: Branches
------------------------------------------------------------

IF OBJECT_ID('bronze.branches','U') IS NOT NULL
    DROP TABLE bronze.branches;
GO

CREATE TABLE bronze.branches
(
    branch_id INT IDENTITY(1,1) NOT NULL,

    branch_code VARCHAR(10) NOT NULL,

    branch_name VARCHAR(100) NOT NULL,

    city VARCHAR(50) NOT NULL,

    region VARCHAR(50) NOT NULL,

    manager_name VARCHAR(100) NULL,

    phone VARCHAR(20) NULL,

    opened_date DATE NULL,

    status VARCHAR(20) NOT NULL
        CONSTRAINT DF_bronze_branches_status
        DEFAULT ('Active'),

    created_at DATETIME2 NOT NULL
        CONSTRAINT DF_bronze_branches_created_at
        DEFAULT (SYSDATETIME()),

    updated_at DATETIME2 NULL,

    CONSTRAINT PK_bronze_branches
        PRIMARY KEY CLUSTERED (branch_id),

    CONSTRAINT UQ_bronze_branches_code
        UNIQUE(branch_code),

    CONSTRAINT CK_bronze_branches_status
        CHECK (status IN ('Active','Closed'))
);
GO

------------------------------------------------------------
-- Indexes
------------------------------------------------------------

CREATE INDEX IX_bronze_branches_city
ON bronze.branches(city);
GO

CREATE INDEX IX_bronze_branches_region
ON bronze.branches(region);
GO

CREATE INDEX IX_bronze_branches_status
ON bronze.branches(status);
GO