/*
==========================================================
Project : Enterprise Banking Data Engineering Platform
File    : create_database.sql
Purpose : Create the project database
==========================================================
*/

IF DB_ID('EnterpriseBankingDW') IS NOT NULL
BEGIN
    ALTER DATABASE EnterpriseBankingDW
    SET SINGLE_USER WITH ROLLBACK IMMEDIATE;

    DROP DATABASE EnterpriseBankingDW;
END;
GO

CREATE DATABASE EnterpriseBankingDW;
GO

USE EnterpriseBankingDW;
GO