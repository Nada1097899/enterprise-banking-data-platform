import os
import pandas as pd

BRONZE_DIR = "data/bronze"


# ==========================================
# Column Mapping
# ==========================================

COLUMN_RENAMES = {

    "loans.csv": {
        "loan_amount": "principal_amount",
        "status": "loan_status",
    },

    "cards.csv": {
        "status": "card_status",
    },

    "campaigns.xlsx": {
        "status": "campaign_status",
    },

}


# ==========================================
# Apply Mapping
# ==========================================

for file_name, mapping in COLUMN_RENAMES.items():

    file_path = os.path.join(BRONZE_DIR, file_name)

    if not os.path.exists(file_path):
        print(f"⚠️ Not found: {file_name}")
        continue

    print("=" * 70)
    print(f"Processing: {file_name}")

    if file_name.endswith(".csv"):
        df = pd.read_csv(file_path)
    else:
        df = pd.read_excel(file_path)

    print("Before:")
    print(list(df.columns))

    # Rename columns
    df.rename(columns=mapping, inplace=True)

    print("After:")
    print(list(df.columns))

    # Save
    if file_name.endswith(".csv"):
        df.to_csv(
            file_path,
            index=False,
            encoding="utf-8-sig"
        )
    else:
        df.to_excel(
            file_path,
            index=False
        )

    print(f"✅ Updated: {file_name}")


print("=" * 70)
print("✅ Bronze column mapping completed.")